# -*- coding: utf-8 -*-
"""重抓 ETF / 创业板 主力资金流 TOP25（流入+流出），覆盖写入 market_data_YYYYMMDD.json fund_flow
用法: python fetch_flow_top20.py [YYYY-MM-DD]   （省略则默认当天）"""
import json, sys, os, datetime
import time, urllib.request, urllib.parse

if len(sys.argv) > 1:
    TRADE_DATE = sys.argv[1]
else:
    TRADE_DATE = datetime.date.today().isoformat()
HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.environ.get("REPORT_OUT_DIR") or os.getcwd()
STAMP = TRADE_DATE.replace("-", "")
PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))

# ── 缓存优先：已有 fund_flow 数据则跳过抓取，避免触发第三方限流(429) ──
if os.path.exists(PATH):
    with open(PATH, "r", encoding="utf-8") as _f:
        _d = json.load(_f)
    if "fund_flow" in _d and _d["fund_flow"].get("etf") and _d["fund_flow"].get("gem"):
        print("✔ fund_flow 缓存已存在，复用: {}".format(PATH))
        print("  （如需强制重抓，请删除该 JSON 后重跑）")
        sys.exit(0)

BASE = "https://push2delay.eastmoney.com/api/qt/clist/get"
HDRS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://data.eastmoney.com/",
}
PZ = 35  # 一次取全，截断前25

def fetch(fs, po):
    params = {
        "pn": "1", "pz": str(PZ), "po": str(po), "np": "1",
        "fltt": "2", "invt": "2", "fid": "f62",
        "fs": fs,
        "fields": "f12,f14,f62",
    }
    url = BASE + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=HDRS)
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read().decode("utf-8"))
            diff = (data.get("data") or {}).get("diff") or []
            rows = []
            for it in diff:
                v = it.get("f62")
                if v in (None, "-"):
                    continue
                rows.append({
                    "code": str(it.get("f12", "")),
                    "name": str(it.get("f14", "")),
                    "main_net_yi": round(float(v) / 1e8, 2),
                })
            return rows
        except Exception as e:
            print("  retry", attempt, repr(e)[:120])
            time.sleep(2)
    return []

ETFS = "b:MK0021,b:MK0022,b:MK0023,b:MK0024,b:MK0827"
GEMS = "m:0+t:80"

out = {}
print("== ETF inflow ==")
out["etf_in"] = fetch(ETFS, 1)
print("  got", len(out["etf_in"]), out["etf_in"][0] if out["etf_in"] else None)
print("== ETF outflow ==")
out["etf_out"] = fetch(ETFS, 0)
print("  got", len(out["etf_out"]), out["etf_out"][0] if out["etf_out"] else None)
print("== GEM inflow ==")
out["gem_in"] = fetch(GEMS, 1)
print("  got", len(out["gem_in"]), out["gem_in"][0] if out["gem_in"] else None)
print("== GEM outflow ==")
out["gem_out"] = fetch(GEMS, 0)
print("  got", len(out["gem_out"]), out["gem_out"][0] if out["gem_out"] else None)

if not (out["etf_in"] and out["etf_out"] and out["gem_in"] and out["gem_out"]):
    print("ERROR: 有组数据为空，中止写入")
    raise SystemExit(1)

path = PATH
if not os.path.exists(path):
    raise SystemExit("JSON 不存在: {}".format(path))
with open(path, "r", encoding="utf-8") as f:
    d = json.load(f)
d["fund_flow"] = {
    "etf": {"inflow": out["etf_in"][:25], "outflow": out["etf_out"][:25]},
    "gem": {"inflow": out["gem_in"][:25], "outflow": out["gem_out"][:25]},
}
with open(path, "w", encoding="utf-8") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
print("written ->", path)

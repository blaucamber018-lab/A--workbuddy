# -*- coding: utf-8 -*-
"""一次性升级脚本：把标准版 HTML 中 limit-trend 折线图从 620×218 升级为 1200×280 原生画布。
数据来源：从现有 HTML 的 SVG 中解析（circle cx 对应数值标签），与 fetch_limit_history 口径一致。
实现：从 build_bview_final.py 用正则精确提取 _build_limit_trend_svg 函数源码 → exec 编译 → 用真实数据重绘。
用法: python upgrade_trend_svg_1200.py <html_path>
"""
import datetime
import os
import re
import sys

HERE = os.path.dirname(__file__)
BUILD = os.path.join(HERE, "build_bview_final.py")


def extract_history_from_svg(svg):
    """从旧 SVG 中解析 15 日 up/down 序列与日期抽样标签"""
    circles = re.findall(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="2.8" fill="(#E60012|#0a8a3a)"', svg)
    texts = re.findall(
        r'<text x="([\d.]+)" y="([\d.]+)" font-size="8.5" fill="(#E60012|#0a8a3a)" '
        r'text-anchor="middle" font-weight="700">(\d+)</text>', svg)
    date_labels = re.findall(r'font-size="9"[^>]*>(\d+/\d+)</text>', svg)
    ups, downs = [], []
    for cx, cy, col in circles:
        for t in texts:
            if abs(float(t[0]) - float(cx)) < 0.01 and t[2] == col:
                if col == "#E60012":
                    ups.append(int(t[3]))
                else:
                    downs.append(int(t[3]))
                break
    return ups, downs, date_labels


def infer_dates(date_labels, n):
    """从最后日期标签倒推 n 个交易日（跳过周末），返回 YYYY-MM-DD 序列"""
    last = date_labels[-1]  # e.g. 09/24
    last_dt = datetime.date(2026, int(last.split("/")[0]), int(last.split("/")[1]))
    dates, cur = [], last_dt
    while len(dates) < n:
        if cur.weekday() < 5:
            dates.append(cur.isoformat())
        cur -= datetime.timedelta(days=1)
    dates.reverse()
    return dates


def load_trend_fn():
    """正则提取 build_bview_final.py 中 _build_limit_trend_svg 函数源码并编译"""
    src = open(BUILD, encoding="utf-8").read()
    m = re.search(r'\ndef _build_limit_trend_svg\(history\):.*?\n    return "".join\(parts\)\n', src, re.S)
    assert m, "_build_limit_trend_svg 源码未找到"
    ns = {}
    exec(compile(m.group(0), "<trend_fn>", "exec"), ns)
    return ns["_build_limit_trend_svg"]


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "assets", "standard-report-20260924.html")
    path = os.path.abspath(path)
    html = open(path, encoding="utf-8").read()
    idx = html.find('id="limit-trend"')
    assert idx != -1, "limit-trend card not found"
    m = re.search(r'<svg.*?</svg>', html[idx:idx + 30000], re.S)
    assert m, "limit-trend svg not found"
    old_svg = m.group(0)
    ups, downs, date_labels = extract_history_from_svg(old_svg)
    n = len(ups)
    assert n == len(downs) and n >= 2, "bad data: up=%d down=%d" % (len(ups), len(downs))
    dates = infer_dates(date_labels, n)
    history = [{"date": d, "up": u, "down": dn} for d, u, dn in zip(dates, ups, downs)]

    fn = load_trend_fn()
    new_svg = fn(history)
    assert new_svg, "new svg empty"
    print("旧 SVG: %s  len=%d" % (re.search(r'viewBox="[^"]+"', old_svg).group(0), len(old_svg)))
    print("新 SVG: %s  len=%d" % (re.search(r'viewBox="[^"]+"', new_svg).group(0), len(new_svg)))
    print("数据: %d 日" % n)
    print("  up  : %s" % ups)
    print("  down: %s" % downs)
    print("  日期: %s" % dates)
    print("  日期标签(抽样): %s" % date_labels)

    html = html.replace(old_svg, new_svg, 1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print("已替换 ->", path)


if __name__ == "__main__":
    main()

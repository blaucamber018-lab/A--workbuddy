# -*- coding: utf-8 -*-
"""A股市场情绪日报 - 复盘增强模块抓取与规则计算 (fetch_replay.py)
在 market_data_{date}.json 基础上，新增 replay 字段：
  - market_overview.amount_wan    沪深两市成交额(万元, 上证+深证 f6)
  - limit_up                       涨停池 {count, first_count, first_pct, max_board, max_name,
                                          max_code, boards{板数:只数},
                                          by_industry[{name,count,lbc,leader{name,code,lbc,fbt}}]}
  - limit_down.count               跌停数
  - industry_flow                  行业主力净流入 TOP10 / 流出 TOP10 (从 industry.all 派生)
  - sector_strength                板块强度评分 TOP10 (规则打分)
  - market_style                   市场风格分析 (大盘/小盘·成长/价值·科技/周期/消费·风险偏好)
  - top_changes                    今日最大变化 TOP5 (规则: 涨幅+资金异动)
  - focus_tomorrow                 明日重点观察 TOP3
用法: python fetch_replay.py [YYYY-MM-DD]  (默认当天，需先有 market_data JSON)
"""
import json
import os
import sys
import time
import datetime
import urllib.request
import urllib.parse
from collections import Counter

import ipv4_first  # 强制 IPv4（东财 IPv6 端点断连修复，须在任何网络请求前）

HERE = os.path.dirname(os.path.abspath(__file__))
# 输出目录：REPORT_OUT_DIR（skill 分发场景）→ 否则脚本所在目录（自动化场景）
OUT_DIR = os.environ.get("REPORT_OUT_DIR") or HERE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
HDRS = {"User-Agent": UA, "Referer": "https://data.eastmoney.com/"}

if len(sys.argv) > 1:
    TRADE_DATE = sys.argv[1]
else:
    TRADE_DATE = datetime.date.today().isoformat()
STAMP = TRADE_DATE.replace("-", "")
JSON_PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))


def get(url):
    req = urllib.request.Request(url, headers=HDRS)
    return json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))


def _retry(fn, tries=3, wait=2):
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            print("  重试 {}: {}".format(i + 1, repr(e)[:120]))
            time.sleep(wait)
    return None


# ═══════════════════════════════
# 1. 成交额 (沪深两市) + 指数
# ═══════════════════════════════
def fetch_amount_wan():
    """上证+深证成指 f6(成交额,元) 加总 → 万元"""
    url = ("https://push2delay2.eastmoney.com/api/qt/ulist.np/get?" if os.environ.get("EM_USE_MIRROR")
           else "https://push2delay.eastmoney.com/api/qt/ulist.np/get?") + urllib.parse.urlencode({
        "fltt": "2", "invt": "2",
        "fields": "f6,f12,f14", "secids": "1.000001,0.399001",
        "ut": "bd1d9ddb04089700cf9c27f6f7426281"})
    def _f():
        d = get(url)
        total = 0.0
        for it in (d.get("data") or {}).get("diff") or []:
            total += float(it.get("f6") or 0)
        return round(total / 10000, 0)  # 元 → 万元
    return _retry(_f)


# ═══════════════════════════════
# 2. 涨停池 / 跌停池
# ═══════════════════════════════
def fetch_limit_up():
    """涨停池: 涨停数 / 连板分布 / 最高连板 / 首板占比 / 题材涨停统计"""
    url = "https://push2ex.eastmoney.com/getTopicZTPool?" + urllib.parse.urlencode({
        "ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt",
        "Pageindex": "0", "pagesize": "400", "sort": "fbt:asc",
        "date": STAMP, "_": str(int(time.time()))})
    def _f():
        d = get(url)
        pool = (d.get("data") or {}).get("pool") or []
        if not pool:
            return None
        boards = Counter(int(x.get("lbc", 1) or 1) for x in pool)
        max_board = max(boards.keys())
        max_stock = max(pool, key=lambda x: int(x.get("lbc", 1) or 1))
        # 领涨个股：连板数最高，同为最高连板时封板时间最早（fbt 越小越早封板）
        leader = max(pool, key=lambda x: (int(x.get("lbc", 1) or 1), -int(x.get("fbt", 0) or 0)))
        first_count = boards.get(1, 0)
        total = len(pool)
        # 按行业/题材统计涨停数（涨停池的 hybk 字段）
        ind_cnt = Counter(x.get("hybk", "其他") or "其他" for x in pool)
        # 同时统计连板数较高的题材 + 每个题材的领涨个股（题材内最高连板且封板最早）
        ind_lbc = {}
        ind_leader = {}
        for x in pool:
            k = x.get("hybk", "其他")
            lbc = int(x.get("lbc", 1) or 1)
            fbt = int(x.get("fbt", 0) or 0)
            ind_lbc[k] = max(ind_lbc.get(k, 0), lbc)
            cur = ind_leader.get(k)
            if cur is None or lbc > cur["lbc"] or (lbc == cur["lbc"] and fbt < cur["fbt"]):
                ind_leader[k] = {"name": str(x.get("n", "-")), "code": str(x.get("c", "-")),
                                 "lbc": lbc, "fbt": fbt}
        by_industry = [{"name": k, "count": v, "lbc": ind_lbc.get(k, 1),
                        "leader": ind_leader.get(k, {})}
                       for k, v in ind_cnt.most_common(12)]
        return {
            "count": total,
            "first_count": first_count,
            "first_pct": round(first_count / total * 100, 1) if total else 0,
            "max_board": max_board,
            "max_name": str(max_stock.get("n", "-")),
            "max_code": str(max_stock.get("c", "-")),
            "leader": {"name": str(leader.get("n", "-")),
                       "code": str(leader.get("c", "-")),
                       "lbc": int(leader.get("lbc", 1) or 1),
                       "fbt": int(leader.get("fbt", 0) or 0)},
            "boards": {str(k): v for k, v in sorted(boards.items(), reverse=True)},
            "by_industry": by_industry,
        }
    return _retry(_f)


def fetch_limit_down():
    url = "https://push2ex.eastmoney.com/getTopicDTPool?" + urllib.parse.urlencode({
        "ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt",
        "Pageindex": "0", "pagesize": "200", "sort": "fund:asc",
        "date": STAMP, "_": str(int(time.time()))})
    def _f():
        d = get(url)
        return len((d.get("data") or {}).get("pool") or [])
    return _retry(_f)


def fetch_zhaban():
    """炸板池: 当日炸板数（盘中摸到涨停、但收盘未封住涨停的股票只数）"""
    url = "https://push2ex.eastmoney.com/getTopicZBPool?" + urllib.parse.urlencode({
        "ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt",
        "Pageindex": "0", "pagesize": "400", "sort": "fbt:asc",
        "date": STAMP, "_": str(int(time.time()))})
    def _f():
        d = get(url)
        return len((d.get("data") or {}).get("pool") or [])
    return _retry(_f)


# ═══════════════════════════════
# 3. 行业资金流 + 板块强度 + 风格 + 变化 + 明日
# ═══════════════════════════════
def _num(x, d=0.0):
    try:
        v = float(x)
        return v
    except Exception:
        return d


def build_replay(d):
    industry = d.get("industry") or {}
    inds = industry.get("all") or []
    breadth = (d.get("market") or {}).get("breadth") or {}
    main_net = (d.get("market") or {}).get("main_net_inflow_wan") or 0

    # ── 行业主力净流入 TOP10 / 流出 TOP10 (单位: 亿) ──
    def _net(x):
        return _num(x.get("main_net"), 0) / 1e8  # 元→亿
    def _ratio(x):
        return _num(x.get("main_ratio"), 0)
    flow_sorted = sorted(inds, key=_net, reverse=True)
    inflow = [{"name": x.get("name"), "chg": _num(x.get("change_pct")),
               "net": round(_net(x), 2), "ratio": _ratio(x),
               "code": x.get("code")} for x in flow_sorted[:10]]
    outflow = [{"name": x.get("name"), "chg": _num(x.get("change_pct")),
                "net": round(_net(x), 2), "ratio": _ratio(x),
                "code": x.get("code")} for x in flow_sorted[-10:]]

    # ── 板块强度评分 (100分制): 涨跌幅(0-50) + 主力净流入(0-40) + 涨停(0-10) ──
    strength = []
    for x in inds:
        chg = _num(x.get("change_pct"))
        net = _net(x)
        up_cnt = _num(x.get("up_count"))
        # 涨跌幅得分: 0~50, |chg|8% → 50
        s_chg = min(50.0, max(0.0, chg / 8.0 * 50))
        # 资金得分: 净流入每 50亿 得满分40 (取正)
        s_fund = min(40.0, max(0.0, net / 50.0 * 40))
        # 涨停家数得分
        s_zt = min(10.0, up_cnt * 2.5)
        score = round(s_chg + s_fund + s_zt, 0)
        strength.append({"name": x.get("name"), "score": score, "chg": chg,
                         "net": round(net, 2), "up_cnt": int(up_cnt)})
    strength.sort(key=lambda s: s["score"], reverse=True)
    strength = strength[:10]

    # ── 市场风格分析 (规则) ──
    up = breadth.get("up", 0) or 0
    down = breadth.get("down", 0) or 0
    flat = breadth.get("flat", 0) or 0
    total_br = up + down + flat or 1
    # 涨跌家数比 → 风险偏好
    ud_ratio = up / (down + 1)
    if ud_ratio >= 1.5:
        risk = "风险偏好提升"
        risk_score = min(100, round(50 + ud_ratio * 6, 0))
        risk_trend = "↑"
    elif ud_ratio >= 0.8:
        risk = "风险偏好中性"
        risk_score = round(50 + (ud_ratio - 0.8) * 30, 0)
        risk_trend = "→"
    else:
        risk = "风险偏好收缩"
        risk_score = max(10, round(50 - (0.8 - ud_ratio) * 40, 0))
        risk_trend = "↓"
    # 大盘/小盘、成长/价值、科技/周期/消费：用行业涨跌榜聚类近似
    leading_names = [x.get("name") for x in inds if _num(x.get("change_pct")) > 0][:12]
    lagging_names = [x.get("name") for x in inds if _num(x.get("change_pct")) < 0][:12]
    tech_kw = ["电子", "半导体", "通信", "计算机", "元件", "软件", "消费电子", "光学", "机器人", "算力", "芯片", "人工智能"]
    cyc_kw = ["有色", "钢铁", "煤炭", "化工", "建材", "房地产", "建筑", "机械", "银行", "非银"]
    con_kw = ["食品", "饮料", "白酒", "医药", "医疗", "零售", "旅游", "家电", "汽车", "纺织", "农业"]
    def _hit(names, kws):
        return sum(1 for n in names if any(k in (n or "") for k in kws))
    tech_hit = _hit(leading_names, tech_kw) - _hit(lagging_names, tech_kw)
    cyc_hit = _hit(leading_names, cyc_kw) - _hit(lagging_names, cyc_kw)
    con_hit = _hit(leading_names, con_kw) - _hit(lagging_names, con_kw)
    grp = {"科技": tech_hit, "周期": cyc_hit, "消费": con_hit}
    if sum(grp.values()) == 0:
        leader_style = "均衡"
        leader_style_score = 50
    else:
        leader_style = max(grp, key=lambda k: grp[k])
        leader_style_score = round(50 + grp[leader_style] * 5, 0)
    # 成长/价值: 科技强→成长占优；周期/消费强→价值占优
    gv = "成长占优" if tech_hit > 0 else ("价值占优" if (cyc_hit + con_hit) > 0 else "风格均衡")
    gv_score = round(50 + abs(tech_hit) * 4, 0)
    # 大小盘: 用平均涨幅较高的行业数量占比近似(简化: 涨停多/活跃→小盘活跃)
    if ud_ratio >= 1.2:
        cap = "小盘占优"; cap_score = round(55 + min(20, (ud_ratio - 1.2) * 25), 0)
    elif ud_ratio <= 0.7:
        cap = "大盘占优"; cap_score = round(55 + min(20, (0.7 - ud_ratio) * 25), 0)
    else:
        cap = "风格均衡"; cap_score = 50

    style = {
        "cap": {"label": cap, "score": cap_score},
        "gv": {"label": gv, "score": gv_score},
        "grp": {"label": "科技占优" if leader_style == "科技" else ("周期占优" if leader_style == "周期"
                else ("消费占优" if leader_style == "消费" else "风格均衡")),
                "score": leader_style_score},
        "risk": {"label": risk, "score": int(risk_score), "trend": risk_trend},
        "up": up, "down": down, "flat": flat,
    }

    # ── 今日最大变化 TOP5 (规则: 资金异动+涨跌幅) ──
    changes = []
    for x in inds:
        chg = _num(x.get("change_pct"))
        net = _net(x)
        # 增强: 大涨+大额流入；减弱: 大跌+大额流出
        if chg >= 2.5 and net >= 8:
            changes.append({"name": x.get("name"), "type": "增强",
                            "desc": "涨幅{:.1f}%，主力净流入{:.1f}亿，资金与价格共振".format(chg, net),
                            "score": chg * 1.5 + net * 0.8})
        elif chg <= -2.5 and net <= -8:
            changes.append({"name": x.get("name"), "type": "减弱",
                            "desc": "跌幅{:.1f}%，主力净流出{:.1f}亿，资金持续流出".format(abs(chg), abs(net)),
                            "score": abs(chg) * 1.5 + abs(net) * 0.8})
    changes.sort(key=lambda c: c["score"], reverse=True)
    changes = changes[:5]

    # ── 明日重点观察 (强度TOP3) ──
    focus = [{"name": s["name"], "score": s["score"], "chg": s["chg"], "net": s["net"]}
             for s in strength[:3]]

    return {
        "amount_wan": fetch_amount_wan(),
        "limit_up": fetch_limit_up(),
        "limit_down": fetch_limit_down(),
        "zhaban": {"count": fetch_zhaban() or 0},
        "industry_flow": {"inflow": inflow, "outflow": outflow},
        "sector_strength": strength,
        "market_style": style,
        "top_changes": changes,
        "focus_tomorrow": focus,
        "main_net_inflow_wan": main_net,
        "breadth": {"up": up, "down": down, "flat": flat},
    }


def main():
    if not os.path.exists(JSON_PATH):
        raise SystemExit("JSON 不存在: {}（请先运行 fetch_data_0807 / fetch_flow_top20）".format(JSON_PATH))
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        d = json.load(f)

    print("抓取成交额 / 涨停池 / 跌停池 ...")
    # 保留已有 limit_history（fetch_limit_history.py 写入的 15 日涨跌停历史），
    # 避免 replay 整体覆盖导致数据丢失（即使脚本执行顺序被打乱）
    _prev_lh = (d.get("replay") or {}).get("limit_history")
    replay = build_replay(d)
    if _prev_lh:
        replay["limit_history"] = _prev_lh
    d["replay"] = replay
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)

    lu = replay["limit_up"] or {}
    print("\n✅ 复盘增强已写入 market_data_{}.json".format(STAMP))
    print("  成交额: {:.2f}亿".format((replay["amount_wan"] or 0) / 10000))
    print("  涨停 {} 只 (首板{} {:.1f}%) / 跌停 {} 只 / 炸板 {} 只".format(
        lu.get("count", "-"), lu.get("first_count", "-"), lu.get("first_pct", 0),
        replay["limit_down"] or "-", (replay.get("zhaban") or {}).get("count", 0)))
    if lu.get("max_name"):
        print("  最高连板: {}板 {}".format(lu.get("max_board"), lu.get("max_name")))
    print("  行业资金流: 流入TOP {} / 流出TOP {}".format(
        len(replay["industry_flow"]["inflow"]), len(replay["industry_flow"]["outflow"])))
    st = replay["sector_strength"]
    if st:
        print("  强度TOP3: " + " / ".join("{} {}分".format(s["name"], s["score"]) for s in st[:3]))
    stl = replay["market_style"]
    print("  风格: {} / {} / {} / {}".format(stl["cap"]["label"], stl["gv"]["label"],
                                             stl["grp"]["label"], stl["risk"]["label"]))
    print("  今日最大变化: {} 条, 明日观察: {} 个".format(
        len(replay["top_changes"]), len(replay["focus_tomorrow"])))


if __name__ == "__main__":
    main()

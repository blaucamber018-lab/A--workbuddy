# -*- coding: utf-8 -*-
"""A股市场情绪日报 - 收盘后自动化主控脚本
流程: 抓龙虎榜/题材/行业 → 抓ETF/创业板资金流 → 抓指数/涨跌家数/主力资金(market)
      → 复盘增强(成交额/涨停跌停池/板块强度/风格/今日变化/明日观察, fetch_replay.py)
      → 近15交易日涨跌停历史(fetch_limit_history.py) → 生成 BVIEW 日报 HTML
用法: python run_daily_report.py [YYYY-MM-DD] [OUTPUT_DIR]
      省略日期则默认当天；省略输出目录则写入当前工作目录。
"""
import json
import os
import sys
import subprocess
import datetime
import time
import urllib.request
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable

# ── 交易日参数化：默认当天 ──
if len(sys.argv) > 1:
    TRADE_DATE = sys.argv[1]
else:
    TRADE_DATE = datetime.date.today().isoformat()
STAMP = TRADE_DATE.replace("-", "")
OUT_DIR = os.path.abspath(sys.argv[2] if len(sys.argv) > 2 else os.getcwd())
os.makedirs(OUT_DIR, exist_ok=True)
JSON_PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))
OUTPUT_HTML = os.path.join(OUT_DIR, "A股市场情绪日报_BVIEW_{}.html".format(STAMP))

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
HDRS = {
    "User-Agent": UA,
    "Referer": "https://data.eastmoney.com/",
}


# ═══════════════════════════════════════════
# market 抓取：5 指数 + 涨跌家数 + 主力资金净流入
# ═══════════════════════════════════════════
def fetch_market():
    """东财 ulist.np/get：5 指数行情 + 沪深两市涨跌家数与主力资金。
    涨跌家数/主力资金取「上证指数(1.000001)+深证成指(0.399001)」两段相加，
    与历史缓存口径一致（全市场约 5280 家，up2708/down2427/flat145，主力364亿）。"""
    indexes_cfg = [
        ("1.000001", "000001", "上证指数"),
        ("0.399006", "399006", "创业板指"),
        ("1.000688", "000688", "科创50"),
        ("100.HSI", "HSI", "恒生指数"),
        ("100.N225", "N225", "日经225"),
    ]
    breadth_cfg = [
        ("1.000001", "上证指数"),
        ("0.399001", "深证成指"),
    ]
    secids = ",".join(c[0] for c in indexes_cfg + breadth_cfg)
    # push2delay2 优先（实测最稳定），push2delay 兜底；两个都断连时返回空并由调用方告警
    hosts = ["https://push2delay2.eastmoney.com", "https://push2delay.eastmoney.com"]
    indexes = []
    up = down = flat = 0
    main_net_wan = 0.0
    bnames = {c[1] for c in breadth_cfg}
    for host in hosts:
        url = host + "/api/qt/ulist.np/get?" + urllib.parse.urlencode({
            "fltt": "2", "invt": "2",
            "fields": "f2,f3,f4,f12,f14,f62,f104,f105,f106",
            "secids": secids,
            "ut": "bd1d9ddb04089700cf9c27f6f7426281",
        })
        req = urllib.request.Request(url, headers=HDRS)
        ok = False
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=20) as r:
                    diff = (json.loads(r.read().decode("utf-8")).get("data") or {}).get("diff") or []
                if not diff:
                    raise ValueError("empty diff")
                for item in diff:
                    name = str(item.get("f14", ""))
                    # 指数行情（5 个指数）
                    if name in {c[2] for c in indexes_cfg}:
                        indexes.append({
                            "code": str(item.get("f12", "")), "name": name,
                            "close": round(float(item.get("f2") or 0), 2),
                            "change_pct": round(float(item.get("f3") or 0), 2),
                            "change": round(float(item.get("f4") or 0), 2),
                        })
                    # 涨跌家数 & 主力资金：上证 + 深证成指 两段相加
                    if name in bnames:
                        up += int(item.get("f104") or 0)
                        down += int(item.get("f105") or 0)
                        flat += int(item.get("f106") or 0)
                        main_net_wan += float(item.get("f62") or 0)
                ok = True
                break
            except Exception as e:
                print("  market 抓取重试({})".format(host), attempt, repr(e)[:120])
                time.sleep(2)
        if ok:
            break
    main_net_wan = round(main_net_wan / 10000, 1)  # 元 → 万元
    return {
        "indexes": indexes,
        "breadth": {"up": up, "down": down, "flat": flat},
        "main_net_inflow_wan": main_net_wan,
    }


def _market_ok(market):
    """校验 market 抓取是否完整（5 指数齐全 + 涨跌家数非全 0）"""
    if not market or len(market.get("indexes") or []) < 5:
        return False
    b = market.get("breadth") or {}
    return (b.get("up") or 0) + (b.get("down") or 0) > 0


def probe_trade_date(start_date):
    """从 start_date 往前（含当天）回溯最近一个 A股交易日。
    判断依据：东财龙虎榜接口在该日期是否有数据（休市/节假日返回 0 条）。
    返回 (交易日字符串, 是否回退)。"""
    cur = datetime.date.fromisoformat(start_date)
    for _ in range(10):
        ds = cur.isoformat()
        if _is_trade_day(ds):
            return ds, (ds != start_date)
        cur -= datetime.timedelta(days=1)
    return start_date, False


def _is_trade_day(ds):
    """通过龙虎榜接口探测某日期是否为交易日（返回>0条即有数据）。"""
    url = ("https://datacenter-web.eastmoney.com/api/data/v1/get?" +
           urllib.parse.urlencode({
               "reportName": "RPT_DAILYBILLBOARD_DETAILSNEW",
               "columns": "ALL",
               "filter": "(TRADE_DATE>='{}')(TRADE_DATE<='{}')".format(ds, ds),
               "pageNumber": "1", "pageSize": "5",
               "sortColumns": "BILLBOARD_NET_AMT", "sortTypes": "-1",
               "source": "WEB", "client": "WEB",
           }))
    try:
        req = urllib.request.Request(url, headers=HDRS)
        d = json.loads(urllib.request.urlopen(req, timeout=15).read().decode("utf-8"))
        res = d.get("result") or {}
        return len(res.get("data") or []) > 0
    except Exception as e:
        print("  交易日探测失败: {}".format(repr(e)[:80]))
        return True  # 探测失败时假定为交易日，交给主流程处理


def step(name, cmd):
    print("\n───── {} ─────".format(name))
    env = dict(os.environ, REPORT_OUT_DIR=OUT_DIR)
    r = subprocess.run([PY, os.path.join(HERE, cmd), TRADE_DATE],
                       cwd=OUT_DIR, env=env, capture_output=True, text=True, encoding="utf-8")
    print(r.stdout[-3000:] if r.stdout else "")
    if r.returncode != 0:
        print("!! 失败:", r.stderr[-1500:] if r.stderr else "unknown")
        raise SystemExit("步骤 {} 失败".format(cmd))
    return r


def main():
    global TRADE_DATE, STAMP, JSON_PATH, OUTPUT_HTML, OUT_DIR
    print("=" * 60)
    print("A股市场情绪日报 自动化 · 请求日期 {}".format(TRADE_DATE))
    print("=" * 60)

    # ── 最近交易日探测与自动回退 ──
    resolved, rolled = probe_trade_date(TRADE_DATE)
    if rolled:
        print("⚠  {} 非交易日，自动回退到最近交易日 {}".format(TRADE_DATE, resolved))
        TRADE_DATE = resolved
        STAMP = TRADE_DATE.replace("-", "")
        JSON_PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))
        OUTPUT_HTML = os.path.join(OUT_DIR, "A股市场情绪日报_BVIEW_{}.html".format(STAMP))
    print("✔  使用交易日 {}".format(TRADE_DATE))

    # 1. 抓龙虎榜/题材/行业
    step("抓取龙虎榜/题材/行业板块", "fetch_data_0807.py")
    # 2. 抓 ETF/创业板 资金流
    step("抓取 ETF/创业板 主力资金流", "fetch_flow_top20.py")
    # 3. 抓 market（指数/涨跌家数/主力资金）并写入 JSON
    print("\n───── 抓取指数/涨跌家数/主力资金(market) ─────")
    if not os.path.exists(JSON_PATH):
        raise SystemExit("JSON 不存在: {}".format(JSON_PATH))
    market = fetch_market()
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        d = json.load(f)
    if not _market_ok(market):
        # 抓取不完整 → 若已有历史 market 则保留（绝不用空壳覆盖，否则指数卡片空白）
        old_mk = d.get("market") or {}
        old_ok = (len(old_mk.get("indexes") or []) >= 5
                  and ((old_mk.get("breadth") or {}).get("up") or 0) > 0)
        print("!! 警告: market 抓取不完整（指数{}个 / 涨{} 跌{} 平{}）".format(
            len(market.get("indexes") or []),
            (market.get("breadth") or {}).get("up", 0),
            (market.get("breadth") or {}).get("down", 0),
            (market.get("breadth") or {}).get("flat", 0)))
        if old_ok:
            print("  保留已有 market（{} 指数，不覆盖）".format(len(old_mk.get("indexes") or [])))
        else:
            print("  !! JSON 中也无完整 market，写入当前抓取结果")
            d["market"] = market
    else:
        d["market"] = market
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    print("  market 已写入: 指数{}个 / 涨{} 跌{} 平{} / 主力净流入{:.0f}万".format(
        len(d["market"].get("indexes") or []),
        (d["market"].get("breadth") or {}).get("up", 0),
        (d["market"].get("breadth") or {}).get("down", 0),
        (d["market"].get("breadth") or {}).get("flat", 0),
        d["market"].get("main_net_inflow_wan", 0) or 0))

    # 4. 复盘增强: 成交额/涨停跌停池/行业资金流TOP/板块强度/市场风格/今日变化/明日观察
    step("复盘增强数据抓取与规则计算", "fetch_replay.py")

    # 4.5 近15交易日涨跌停历史（涨停/跌停双折线图数据）
    step("近15交易日涨跌停历史", "fetch_limit_history.py")

    # 5. 生成 BVIEW HTML
    step("生成 BVIEW 日报 HTML", "build_bview_final.py")

    if os.path.exists(OUTPUT_HTML):
        size = os.path.getsize(OUTPUT_HTML)
        print("\n✅ 完成: {}".format(OUTPUT_HTML))
        print("   文件大小 {:.1f} KB".format(size / 1024))
    else:
        print("\n!! 未生成输出文件: {}".format(OUTPUT_HTML))
        raise SystemExit("输出文件缺失")


if __name__ == "__main__":
    main()

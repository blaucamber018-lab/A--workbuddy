# -*- coding: utf-8 -*-
"""BVIEW VI 风格 A股市场情绪日报生成器（复用已抓取真实数据，Logo 内联）。
用法: python build_bview_final.py [YYYY-MM-DD]   （省略则默认当天）"""
import base64
import datetime
import html
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
# 输出目录：REPORT_OUT_DIR（skill 分发场景）→ 否则脚本所在目录（自动化场景）
OUT_DIR = os.environ.get("REPORT_OUT_DIR") or HERE
# ── 交易日参数化：默认当天 ──
if len(sys.argv) > 1:
    TRADE_DATE = sys.argv[1]
else:
    TRADE_DATE = datetime.date.today().isoformat()
STAMP = TRADE_DATE.replace("-", "")
DATA_PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))
# Logo 探测：优先脚本同目录，其次 skill 的 assets/ 目录
_LOGO_CANDIDATES = [os.path.join(HERE, "bview-logo.png"),
                    os.path.join(HERE, "..", "assets", "bview-logo.png")]
LOGO_PATH = next((p for p in _LOGO_CANDIDATES if os.path.exists(p)), _LOGO_CANDIDATES[0])
OUTPUT = os.path.join(OUT_DIR, "A股市场情绪日报_BVIEW_{}.html".format(STAMP))
WEEKDAY = "周{}".format("一二三四五六日"[datetime.date.fromisoformat(TRADE_DATE).weekday()])

with open(DATA_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)

dt = data["dragon_tiger"]
ht = data["hot_themes"]
ind = data["industry"]
mk = data.get("market", {})
indexes = mk.get("indexes", [])
breadth = mk.get("breadth", {})
main_net_wan = mk.get("main_net_inflow_wan", 0) or 0

ff = data.get("fund_flow", {})
# ── fund_flow 空数据兜底：新交易日东财断连时，从同目录最近含 fund_flow 的历史 JSON 复用 ──
if not ((ff.get("etf") or {}).get("inflow") or []):
    try:
        _hist = sorted(
            (f for f in os.listdir(OUT_DIR)
             if f.startswith("market_data_") and f.endswith(".json") and f != os.path.basename(DATA_PATH)),
            reverse=True)
        for _f in _hist:
            try:
                with open(os.path.join(OUT_DIR, _f), "r", encoding="utf-8") as _fh:
                    _d = json.load(_fh)
                _ff = _d.get("fund_flow") or {}
                if (_ff.get("etf") or {}).get("inflow") or (_ff.get("gem") or {}).get("inflow"):
                    ff = _ff
                    print("  fund_flow 为空，复用历史 {} 的 ETF/创业板资金流数据".format(_f))
                    break
            except Exception:
                continue
    except Exception:
        pass
etf_inflow = (ff.get("etf") or {}).get("inflow") or []
etf_outflow = (ff.get("etf") or {}).get("outflow") or []
gem_inflow = (ff.get("gem") or {}).get("inflow") or []
gem_outflow = (ff.get("gem") or {}).get("outflow") or []

lhb = list(dt["stocks"])
lhb.sort(key=lambda x: -(x.get("net_buy_wan", 0) or 0))
total_records = len(lhb)
unique_codes = len({x.get("code") for x in lhb})
total_net_wan = sum(x.get("net_buy_wan", 0) or 0 for x in lhb)

strong_stocks = ht.get("stocks", [])
topic_counter = Counter()
for s in strong_stocks:
    for t in (s.get("reason", "") or "").split("+"):
        t = t.strip()
        if t:
            topic_counter[t] += 1
top_topics = topic_counter.most_common(15)
top_themes = ht.get("top_themes", []) or [{"name": k, "count": v} for k, v in top_topics]
tag_count = ht.get("total_tags") or sum(topic_counter.values())

industries = list(ind["all"])
leading = ind.get("leading") or industries[:10]
lagging = ind.get("lagging") or industries[-10:][::-1]
ind_up = ind.get("up", sum(1 for x in industries if x["change_pct"] > 0))
ind_down = ind.get("down", sum(1 for x in industries if x["change_pct"] < 0))
hottest = top_themes[0]["name"] if top_themes else "—"
hottest_count = top_themes[0]["count"] if top_themes else 0
leading_ind = leading[0]["name"] if leading else "—"
leading_ind_chg = leading[0]["change_pct"] if leading else 0
lagging_ind = lagging[0]["name"] if lagging else "—"
lagging_ind_chg = lagging[0]["change_pct"] if lagging else 0

# ── 复盘增强模块 (replay) ──
RP = data.get("replay", {})
amount_wan = RP.get("amount_wan", 0) or 0
limit_up = RP.get("limit_up") or {}
limit_down = RP.get("limit_down", 0) or 0
limit_history = RP.get("limit_history", []) or []
ind_flow = RP.get("industry_flow") or {}
ind_flow_in = ind_flow.get("inflow", []) or []
ind_flow_out = ind_flow.get("outflow", []) or []
sector_strength = RP.get("sector_strength", []) or []
market_style = RP.get("market_style") or {}
top_changes = RP.get("top_changes", []) or []
focus_tomorrow = RP.get("focus_tomorrow", []) or []
zhaban = RP.get("zhaban") or {}
zha_count = zhaban.get("count", 0) or 0


def esc(s):
    return html.escape(str(s or ""), quote=False)


def fmt_amount(wan):
    wan = wan or 0
    if abs(wan) >= 10000:
        return "¥{:+.2f}亿".format(wan / 10000)
    return "¥{:+.0f}万".format(wan)


def fmt_amount_plain(wan):
    wan = wan or 0
    if abs(wan) >= 10000:
        return "¥{:.2f}亿".format(wan / 10000)
    return "¥{:.0f}万".format(wan)


def fmt_pct(v):
    return "{:+.2f}%".format(v or 0)


# ---------------- Logo ----------------
with open(LOGO_PATH, "rb") as f:
    logo_b64 = base64.b64encode(f.read()).decode("ascii")
LOGO_URI = "data:image/png;base64," + logo_b64

# ---------------- SVG: 题材热度 TOP10 ----------------
def build_topic_svg(topics):
    items = topics[:10]
    if not items:
        return ""
    max_c = max(c for _, c in items)
    rows = []
    h = 34
    for i, (name, cnt) in enumerate(items):
        y = 26 + i * h
        bar_max = 330
        w = max(4, int(cnt / max_c * bar_max))
        alpha = 0.48 + 0.52 * (cnt / max_c)
        rows.append("""
      <text x="0" y="{y}" fill="#1a1a2e" font-size="12.5" font-weight="600">{name}</text>
      <rect x="168" y="{y1}" width="{w}" height="16" rx="4" fill="url(#tg)" opacity="{alpha}"/>
      <text x="{valx}" y="{y}" fill="#C00010" font-size="12" font-weight="800">{cnt}只</text>
      <text x="552" y="{y}" fill="#8a8a8a" font-size="10.5" text-anchor="end">{pct}%</text>""".format(
            name=esc(name), y=y, y1=y - 10, w=w, alpha=round(alpha, 2),
            valx=172 + w, cnt=cnt, pct=round(cnt / max_c * 100)))
    total_h = 26 + len(items) * h + 12
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 620 {total_h}" width="100%" height="{total_h}" style="display:block">
  <defs>
    <linearGradient id="tg" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#E60012"/>
      <stop offset="100%" stop-color="#FF4D4D"/>
    </linearGradient>
  </defs>
  {rows}
</svg>""".format(total_h=total_h, rows="".join(rows))


# ---------------- SVG: 行业领涨/领跌 TOP10 ----------------
def build_ind_svg():
    lead = leading[:10]
    lag = lagging[:10]
    # 动态满刻度 + 条宽安全上限：避免极端涨跌幅（如 -3%+ / +10%+）把条和数值
    # 拉出卡片 viewBox(760) 外。正常数据（涨幅<9%、跌幅<2%）比例与旧版完全一致。
    MAX_W = 150  # 条宽上限：领跌数值 x<=544+150+文字宽<760；领涨不压右侧列
    max_up = max([abs(x["change_pct"]) for x in lead] or [0])
    scale_up = max(max_up, 9.0)
    max_dn = max([abs(x["change_pct"]) for x in lag] or [0])
    scale_dn = max(max_dn, 2.0)
    rows = []
    h = 40
    top_y = 44
    for i, item in enumerate(lead):
        y = top_y + i * h
        pct = item["change_pct"]
        w = max(4, min(abs(pct) / scale_up * 180, MAX_W))
        rows.append("""
      <text x="0" y="{y}" fill="#1a1a2e" font-size="14" font-weight="600">{name}</text>
      <rect x="158" y="{y1}" width="{w}" height="17" rx="4" fill="#E60012" opacity="0.78"/>
      <text x="{valx}" y="{y}" fill="#E60012" font-size="13.5" font-weight="800">{pct}</text>""".format(
            name=esc(item["name"][:6]), y=y, y1=y - 12, w=w, valx=162 + w, pct=fmt_pct(pct)))
    for i, item in enumerate(lag):
        y = top_y + i * h
        pct = item["change_pct"]
        w = max(4, min(abs(pct) / scale_dn * 180, MAX_W))
        rows.append("""
      <text x="382" y="{y}" fill="#1a1a2e" font-size="14" font-weight="600">{name}</text>
      <rect x="540" y="{y1}" width="{w}" height="17" rx="4" fill="#0a8a3a" opacity="0.78"/>
      <text x="{valx}" y="{y}" fill="#0a8a3a" font-size="13.5" font-weight="800">{pct}</text>""".format(
            name=esc(item["name"][:6]), y=y, y1=y - 12, w=w, valx=544 + w, pct=fmt_pct(pct)))
    total_h = top_y + max(len(lead), len(lag)) * h + 14
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 {total_h}" width="100%" height="{total_h}" style="display:block">
  <rect x="0" y="10" width="9" height="9" rx="2.5" fill="#E60012"/>
  <text x="17" y="19" fill="#4a4a4a" font-size="13" font-weight="700">领涨 TOP{ln}</text>
  <rect x="382" y="10" width="9" height="9" rx="2.5" fill="#0a8a3a"/>
  <text x="399" y="19" fill="#4a4a4a" font-size="13" font-weight="700">领跌 TOP{lg}</text>
  {rows}
</svg>""".format(total_h=total_h, ln=len(lead), lg=len(lag), rows="".join(rows))


# ---------------- SVG: 行业全景分布 ----------------
def build_ind_overview_svg():
    all_ind = sorted(industries, key=lambda x: x["change_pct"])
    n = max(len(all_ind), 1)
    max_abs = max((abs(x["change_pct"]) for x in all_ind), default=1) or 1
    bars = []
    slot = (700 - 34) / n
    for i, item in enumerate(all_ind):
        x = 30 + i * slot
        pct = item["change_pct"]
        hgt = abs(pct) / max_abs * 78 if max_abs else 0
        if pct >= 0:
            y = 102 - hgt
            fill = "#E60012"
        else:
            y = 102
            fill = "#0a8a3a"
        bars.append('<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{hgt:.1f}" rx="1" fill="{fill}" opacity="0.8"/>'.format(
            x=x, y=y, w=max(slot - 0.8, 1.2), hgt=max(hgt, 0.8), fill=fill))
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 136" width="100%" height="136" style="display:block">
  <line x1="30" y1="8" x2="30" y2="102" stroke="#ececec" stroke-width="1"/>
  <line x1="30" y1="102" x2="700" y2="102" stroke="#ececec" stroke-width="1"/>
  <text x="18" y="12" fill="#8a8a8a" font-size="10" text-anchor="end">+{max_abs:.1f}%</text>
  <text x="18" y="106" fill="#8a8a8a" font-size="10" text-anchor="end">0</text>
  <text x="18" y="126" fill="#8a8a8a" font-size="10" text-anchor="end">-{max_abs:.1f}%</text>
  {bars}
  <text x="365" y="128" fill="#8a8a8a" font-size="10.5" text-anchor="middle">{n}个行业板块 · {up}涨 {down}跌</text>
</svg>""".format(max_abs=max_abs, bars="".join(bars), n=n, up=ind_up, down=ind_down)


# ---------------- SVG: 龙虎榜净买入 TOP10 ----------------
def build_lhb_svg(stocks):
    items = stocks[:10]
    if not items:
        return ""
    max_abs = max((abs(x["net_buy_wan"]) for x in items), default=1) or 1
    rows = []
    h = 40
    top_y = 50
    for i, item in enumerate(items):
        y = top_y + i * h
        net = item["net_buy_wan"]
        name = "{} {}".format(item.get("code", ""), item.get("name", ""))
        bar_len = int(abs(net) / max_abs * 340)
        if net >= 0:
            fill = "#E60012"
            bar_x = 230
            valx = 234 + bar_len
        else:
            fill = "#0a8a3a"
            bar_x = 230 - bar_len
            valx = 232
        rows.append("""
      <text x="0" y="{y}" fill="#8a8a8a" font-size="11.5">{rank}</text>
      <text x="24" y="{y}" fill="#1a1a2e" font-size="12.5" font-weight="700">{name}</text>
      <rect x="{bar_x}" y="{y1}" width="{w}" height="16" rx="4" fill="{fill}" opacity="0.82"/>
      <text x="{valx}" y="{y}" fill="{fill}" font-size="12.5" font-weight="800">{amount}</text>""".format(
            rank=i + 1, name=esc(name), y=y, y1=y - 10, bar_x=bar_x, w=max(bar_len, 3),
            fill=fill, valx=valx, amount=fmt_amount(net)))
    total_h = top_y + len(items) * h + 14
    baseline = top_y + (len(items) - 1) * h + 8
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 {total_h}" width="100%" height="{total_h}" style="display:block">
  <line x1="230" y1="10" x2="230" y2="{baseline}" stroke="#ececec" stroke-width="1"/>
  <rect x="0" y="12" width="9" height="9" rx="2.5" fill="#E60012"/>
  <text x="17" y="21" fill="#4a4a4a" font-size="13" font-weight="700">净买入</text>
  <rect x="98" y="12" width="9" height="9" rx="2.5" fill="#0a8a3a"/>
  <text x="115" y="21" fill="#4a4a4a" font-size="13" font-weight="700">净卖出</text>
  {rows}
</svg>""".format(total_h=total_h, baseline=baseline, rows="".join(rows))


# ---------------- SVG: ETF / 创业板 主力资金流 ----------------
def fmt_yi(v):
    return "{:+.2f}亿".format(v or 0)

def _flow_rows(items, rank_x, name_x, bar_x, w_max, amt_right, h, top_y, scale="linear", name_len=14):
    """单列资金流条形行（表格化：序号 | 名称 | 条形 | 金额右对齐固定竖线）。
    items: [{name,code,main_net_yi}]（单位亿元）。返回 (rows_html, 行数)。"""
    if not items:
        return "", 0
    mx = max((abs(x.get("main_net_yi", 0) or 0) for x in items), default=1) or 1
    if scale == "sqrt":
        import math
        def wof(v):
            return max(3, math.sqrt(abs(v) / mx) * w_max)
    else:
        def wof(v):
            return max(3, abs(v) / mx * w_max)
    rows = []
    for i, item in enumerate(items):
        y = top_y + i * h
        v = item.get("main_net_yi", 0) or 0
        w = wof(v)
        label = "{} ({})".format(item.get("name", ""), item.get("code", ""))
        fill = "#E60012" if v >= 0 else "#0a8a3a"
        rows.append("""
      <text x="{rx}" y="{y}" fill="#8a8a8a" font-size="11">{rank}</text>
      <text x="{nx}" y="{y}" fill="#1a1a2e" font-size="12" font-weight="600">{label}</text>
      <rect x="{bx}" y="{y1}" width="{w}" height="16" rx="4" fill="{fill}" opacity="0.82"/>
      <text x="{ax}" y="{y}" fill="{fill}" font-size="11.5" font-weight="800" text-anchor="end">{amount}</text>""".format(
            rx=rank_x, y=y, rank=i + 1, nx=name_x, label=esc(label[:name_len]),
            bx=bar_x, y1=y - 11, w=w, fill=fill, ax=amt_right, amount=fmt_yi(v)))
    return "".join(rows), len(items)

def build_etf_svg():
    left, n1 = _flow_rows(etf_inflow[:20], 0, 16, 204, 130, 388, 32, 44, "linear", 24)
    right, n2 = _flow_rows(etf_outflow[:20], 400, 416, 604, 130, 788, 32, 44, "linear", 24)
    total_h = 44 + max(n1, n2, 1) * 32 + 14
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 {total_h}" width="100%" height="auto" style="display:block">
  <rect x="0" y="10" width="9" height="9" rx="2.5" fill="#E60012"/>
  <text x="16" y="19" fill="#4a4a4a" font-size="13" font-weight="700">净流入 TOP{n1}</text>
  <rect x="400" y="10" width="9" height="9" rx="2.5" fill="#0a8a3a"/>
  <text x="416" y="19" fill="#4a4a4a" font-size="13" font-weight="700">净流出 TOP{n2}</text>
  {left}{right}
</svg>""".format(total_h=total_h, n1=n1, n2=n2, left=left, right=right)

def build_gem_svg():
    left, n1 = _flow_rows(gem_inflow[:20], 0, 16, 204, 130, 388, 32, 44, "linear", 14)
    right, n2 = _flow_rows(gem_outflow[:20], 400, 416, 604, 130, 788, 32, 44, "sqrt", 14)
    total_h = 44 + max(n1, n2, 1) * 32 + 14
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 {total_h}" width="100%" height="auto" style="display:block">
  <rect x="0" y="10" width="9" height="9" rx="2.5" fill="#E60012"/>
  <text x="16" y="19" fill="#4a4a4a" font-size="13" font-weight="700">净流入 TOP{n1}</text>
  <rect x="400" y="10" width="9" height="9" rx="2.5" fill="#0a8a3a"/>
  <text x="416" y="19" fill="#4a4a4a" font-size="13" font-weight="700">净流出 TOP{n2}</text>
  {left}{right}
</svg>""".format(total_h=total_h, n1=n1, n2=n2, left=left, right=right)


# ---------------- 龙虎榜表格 ----------------
lb_rows = []
for i, x in enumerate(lhb, 1):
    chg_cls = "up" if x["change_pct"] >= 0 else "down"
    net_cls = "up" if x["net_buy_wan"] >= 0 else "down"
    _reason_full = (x.get("reason") or "").strip()
    lb_rows.append("""<tr data-code="{code}" data-name="{name}" data-net="{netv}" data-reason="{reason_full}">
      <td>{i}</td>
      <td class="code">{code}</td>
      <td class="name">{name}</td>
      <td>{close}</td>
      <td class="{chg_cls}">{chg}</td>
      <td class="{net_cls}">{net}</td>
      <td>{buy}</td>
      <td>{sell}</td>
      <td class="reason" title="{reason}">{reason}</td>
      <td>{turnover}</td>
    </tr>""".format(
        i=i,
        code=esc(x.get("code")),
        name=esc(x.get("name")),
        netv=float(x.get("net_buy_wan") or 0),
        reason_full=html.escape(_reason_full, quote=True),
        close=x.get("close", 0),
        chg_cls=chg_cls,
        chg=fmt_pct(x.get("change_pct")),
        net_cls=net_cls,
        net=fmt_amount(x.get("net_buy_wan")),
        buy=fmt_amount_plain(x.get("buy_wan")),
        sell=fmt_amount_plain(x.get("sell_wan")),
        reason=esc(_reason_full[:44]),
        turnover="{:.2f}%".format(x.get("turnover_pct", 0) or 0)))
lb_table = "\n".join(lb_rows)

_lhb_reasons = sorted({(x.get("reason") or "").strip() for x in lhb if (x.get("reason") or "").strip()})
lhb_reason_options = "".join(
    '<option value="{v}">{v}</option>'.format(v=html.escape(r, quote=True)) for r in _lhb_reasons)

_top_base = top_themes[0]["count"] if top_themes else 1
topic_chips = "".join(
    '<span class="chip" style="background:rgba(230,0,18,{bg});border-color:rgba(230,0,18,{bd})">{name} · {cnt}只</span>'.format(
        bg=round(0.08 + 0.18 * ratio, 2),
        bd=round(0.16 + 0.3 * ratio, 2),
        name=esc(t["name"]), cnt=t["count"])
    for t in top_themes[:12]
    for ratio in [t["count"] / _top_base])

strong_rows = "".join(
    """<tr><td class="code">{code}</td><td class="name">{name}</td><td class="{chg_cls}">{chg}</td><td class="reason">{reason}</td></tr>""".format(
        code=esc(s.get("code")), name=esc(s.get("name")),
        chg_cls="up" if s.get("change_pct", 0) >= 0 else "down",
        chg=fmt_pct(s.get("change_pct")), reason=esc((s.get("reason") or "")[:80]))
    for s in sorted(strong_stocks, key=lambda x: -(x.get("change_pct", 0) or 0))[:12])

topic_svg = build_topic_svg(top_topics)
ind_svg = build_ind_svg()
ind_overview_svg = build_ind_overview_svg()
lhb_svg = build_lhb_svg(lhb)
etf_svg = build_etf_svg()
gem_svg = build_gem_svg()

# ---------------- 市场指数 / 宽度 / 资金 卡片 ----------------
def build_index_cards():
    cells = []
    for ix in indexes:
        up = (ix.get("change_pct") or 0) >= 0
        cls = "up" if up else "down"
        close = ix.get("close") or 0
        close_txt = "{:,.1f}".format(close) if close >= 10000 else "{:,.2f}".format(close)
        cells.append("""
      <div class="index-cell">
        <div class="index-name">{name}</div>
        <div class="index-close">{close}</div>
        <div class="index-chg {cls}">{pct}</div>
      </div>""".format(name=esc(ix.get("name")), close=close_txt, cls=cls, pct=fmt_pct(ix.get("change_pct"))))
    return "".join(cells)


def build_breadth_cards():
    up = breadth.get("up", 0) or 0
    down = breadth.get("down", 0) or 0
    flat = breadth.get("flat", 0) or 0
    net_cls = "up" if main_net_wan >= 0 else "down"
    return """<div class="breadth-cell red">
      <div class="b-num">{up}</div><div class="b-label">上涨家数</div>
    </div><div class="breadth-cell green">
      <div class="b-num">{down}</div><div class="b-label">下跌家数</div>
    </div><div class="breadth-cell gray">
      <div class="b-num">{flat}</div><div class="b-label">平盘家数</div>
    </div><div class="breadth-cell {net_cls}">
      <div class="b-num small">{net}</div><div class="b-label">大盘主力净流入</div>
    </div>""".format(up=up, down=down, flat=flat, net_cls=net_cls, net=fmt_amount(main_net_wan))

index_cards = build_index_cards()
breadth_cards = build_breadth_cards()

# ═══════════════════════════════════════════
# 复盘增强模块渲染
# ═══════════════════════════════════════════
def build_industry_flow_html():
    """行业主力资金流 TOP10 / 流出 TOP10 表格"""
    if not ind_flow_in and not ind_flow_out:
        return ""
    def _rows(items):
        out = []
        for i, x in enumerate(items, 1):
            cls = "up" if x.get("chg", 0) >= 0 else "down"
            out.append(
                "<tr><td>{}</td><td class=\"name\">{}</td><td class=\"{}\">{}</td>"
                "<td class=\"up\">¥{:+.2f}亿</td><td class=\"up\">+{:.1f}%</td></tr>".format(
                    i, esc(x.get("name")), cls, fmt_pct(x.get("chg")),
                    x.get("net", 0) or 0, x.get("ratio", 0) or 0))
        return "".join(out)
    def _block(title, items):
        if not items:
            return ""
        return ("<div class=\"card\"><div class=\"card-head\">"
                "<span class=\"card-title\">{}</span>"
                "<span class=\"card-count\">TOP{}</span></div>"
                "<div class=\"table-wrap\"><table>"
                "<thead><tr><th>#</th><th>行业</th><th>涨跌幅</th><th>主力净流入</th><th>净占比</th></tr></thead>"
                "<tbody>{}</tbody></table></div></div>").format(
                    title, len(items), _rows(items))
    return _block("行业主力净流入 TOP10", ind_flow_in) + _block("行业主力净流出 TOP10", ind_flow_out)


def _build_limit_trend_svg(history):
    """近15交易日 涨停/跌停 双折线图（纯 SVG，红=涨停 #E60012，绿=跌停 #0a8a3a）
    1200×280 原生画布：与通栏卡片等宽渲染，避免小 viewBox 被 width=100% 拉伸后字体/线宽
    等比放大（620→1200 约 1.94 倍）导致版面过大的问题。字号/线宽/点径按原生尺寸设计。
    双 Y 轴：左侧涨停刻度、右侧跌停刻度；底部日期轴；带数据点 + 数值标签 + 图例。
    返回内联 SVG 字符串；历史不足 2 天返回空字符串。"""
    if not history or len(history) < 2:
        return ""
    W, H = 1200, 280
    pad_l, pad_r, pad_t, pad_b = 56, 56, 40, 32
    plot_w, plot_h = W - pad_l - pad_r, H - pad_t - pad_b
    ups = [x.get("up", 0) for x in history]
    downs = [x.get("down", 0) for x in history]
    zhas = [x.get("zha", 0) for x in history]
    max_up, max_dn = max(ups), max(downs)
    # Y 轴上限取最大值向上取整到 5 的倍数，至少 20
    y_up_max = max(20, int((max_up + 9) // 10 * 10))
    y_dn_max = max(20, int((max_dn + 9) // 10 * 10))
    n = len(history)

    def _x(i):
        return pad_l + plot_w * i / (n - 1)

    def _y_up(v):
        return pad_t + plot_h * (1 - v / y_up_max)

    def _y_dn(v):
        return pad_t + plot_h * (1 - v / y_dn_max)

    parts = []
    parts.append('<svg viewBox="0 0 {0} {1}" width="100%" height="auto" xmlns="http://www.w3.org/2000/svg" style="display:block">'.format(W, H))
    # 网格线（水平 4 条）+ Y 轴刻度（左=涨停，右=跌停）
    for g in range(5):
        gy = pad_t + plot_h * g / 4
        v_up = y_up_max * (1 - g / 4)
        v_dn = y_dn_max * (1 - g / 4)
        parts.append('<line x1="{0}" y1="{1}" x2="{2}" y2="{1}" stroke="#efefef" stroke-width="1"/>'.format(pad_l, gy, W - pad_r))
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#8a8a8a" text-anchor="end">{2}</text>'.format(pad_l - 8, gy + 4, int(v_up)))
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#8a8a8a" text-anchor="start">{2}</text>'.format(W - pad_r + 8, gy + 4, int(v_dn)))
    # 折线路径（涨停 / 跌停）
    up_path = " ".join("{} {}".format(_x(i), _y_up(v)) for i, v in enumerate(ups))
    dn_path = " ".join("{} {}".format(_x(i), _y_dn(v)) for i, v in enumerate(downs))
    parts.append('<polyline points="{0}" fill="none" stroke="#E60012" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>'.format(up_path))
    parts.append('<polyline points="{0}" fill="none" stroke="#0a8a3a" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>'.format(dn_path))
    # 炸板折线（蓝 #2E6FE0，虚线，共享左侧涨停刻度）
    zha_path = " ".join("{} {}".format(_x(i), _y_up(v)) for i, v in enumerate(zhas))
    parts.append('<polyline points="{0}" fill="none" stroke="#2E6FE0" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="7 4"/>'.format(zha_path))
    # 面积渐变（涨停浅红、跌停浅绿）
    up_area = "{} {} {} {}".format(pad_l, pad_t + plot_h, " ".join("{} {}".format(_x(i), _y_up(v)) for i, v in enumerate(ups)), pad_l + plot_w)
    dn_area = "{} {} {} {}".format(pad_l, pad_t + plot_h, " ".join("{} {}".format(_x(i), _y_dn(v)) for i, v in enumerate(downs)), pad_l + plot_w)
    parts.append('<defs>'
                 '<linearGradient id="upArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E60012" stop-opacity=".18"/><stop offset="1" stop-color="#E60012" stop-opacity="0"/></linearGradient>'
                 '<linearGradient id="dnArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a8a3a" stop-opacity=".16"/><stop offset="1" stop-color="#0a8a3a" stop-opacity="0"/></linearGradient>'
                 '<linearGradient id="zhaArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2E6FE0" stop-opacity=".13"/><stop offset="1" stop-color="#2E6FE0" stop-opacity="0"/></linearGradient>'
                 '</defs>')
    parts.append('<polygon points="{0}" fill="url(#upArea)"/>'.format(up_area))
    parts.append('<polygon points="{0}" fill="url(#dnArea)"/>'.format(dn_area))
    zha_area = "{} {} {} {}".format(pad_l, pad_t + plot_h, " ".join("{} {}".format(_x(i), _y_up(v)) for i, v in enumerate(zhas)), pad_l + plot_w)
    parts.append('<polygon points="{0}" fill="url(#zhaArea)"/>'.format(zha_area))
    # 数据点 + 数值标签（标签基线做顶部/底部钳制，避免峰值日标签撞图例或日期轴）
    for i, (u, d, z) in enumerate(zip(ups, downs, zhas)):
        parts.append('<circle cx="{0}" cy="{1}" r="4" fill="#E60012" stroke="#fff" stroke-width="1.6"/>'.format(_x(i), _y_up(u)))
        parts.append('<circle cx="{0}" cy="{1}" r="4" fill="#0a8a3a" stroke="#fff" stroke-width="1.6"/>'.format(_x(i), _y_dn(d)))
        parts.append('<circle cx="{0}" cy="{1}" r="4" fill="#2E6FE0" stroke="#fff" stroke-width="1.6"/>'.format(_x(i), _y_up(z)))
        up_ly = max(30, _y_up(u) - 12)
        dn_ly = min(H - pad_b - 2, _y_dn(d) + 18)
        zha_ly = max(34, _y_up(z) - 12)
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#E60012" text-anchor="middle" font-weight="700">{2}</text>'.format(_x(i), up_ly, u))
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#0a8a3a" text-anchor="middle" font-weight="700">{2}</text>'.format(_x(i), dn_ly, d))
        parts.append('<text x="{0}" y="{1}" font-size="11" fill="#2E6FE0" text-anchor="middle" font-weight="700">{2}</text>'.format(_x(i), zha_ly, z))
    # 日期轴（首尾 + 中间 3 个）
    step = max(1, (n - 1) // 4)
    for i in range(0, n, step):
        x = _x(i)
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#8a8a8a" text-anchor="middle">{2}</text>'.format(x, H - 10, history[i]["date"][5:].replace("-", "/")))
    if n >= 2 and (n - 1) % step != 0:
        parts.append('<text x="{0}" y="{1}" font-size="12" fill="#8a8a8a" text-anchor="middle">{2}</text>'.format(_x(n - 1), H - 10, history[-1]["date"][5:].replace("-", "/")))
    # 图例
    parts.append('<text x="{0}" y="{1}" font-size="13" fill="#E60012" font-weight="700">● 涨停</text>'.format(pad_l, 18))
    parts.append('<text x="{0}" y="{1}" font-size="13" fill="#0a8a3a" font-weight="700">● 跌停</text>'.format(pad_l + 88, 18))
    parts.append('<text x="{0}" y="{1}" font-size="13" fill="#2E6FE0" font-weight="700">● 炸板</text>'.format(pad_l + 176, 18))
    parts.append('<text x="{0}" y="{1}" font-size="12" fill="#8a8a8a" text-anchor="end">近{2}个交易日</text>'.format(W - pad_r, 18, n))
    parts.append('</svg>')
    return "".join(parts)


def build_limit_updown_html():
    """涨跌停复盘：涨停数/连板/首板/题材涨停统计（近15日双折线图已移至市场指数卡片下方 limit-trend 卡片）"""
    if not limit_up:
        return ""
    count = limit_up.get("count", 0)
    first_pct = limit_up.get("first_pct", 0)
    max_board = limit_up.get("max_board", 0)
    max_name = limit_up.get("max_name", "-")
    boards = limit_up.get("boards", {}) or {}
    # 连板分布文本
    board_parts = ["{}连板 {}只".format(k, v) for k, v in sorted(boards.items(), key=lambda kv: int(kv[0]), reverse=True)]
    board_txt = " · ".join(board_parts[:5]) if board_parts else "—"
    # 题材涨停统计表（每题材一行，含该题材领涨个股）
    by_ind = limit_up.get("by_industry", []) or []
    ind_rows = "".join(
        "<tr><td class=\"name\">{}</td><td>{}</td><td class=\"up\">{}连板</td>"
        "<td class=\"name\">{}{}</td></tr>".format(
            esc(x.get("name")), x.get("count", 0), x.get("lbc", 1),
            esc((x.get("leader") or {}).get("name") or "-"),
            (" " + esc((x.get("leader") or {}).get("code")) if (x.get("leader") or {}).get("code") else ""))
        for x in by_ind[:8])
    return ("<div class=\"card\" id=\"limitup\"><div class=\"card-head\">"
            "<span class=\"card-title\">涨跌停复盘</span>"
            "<span class=\"card-count\">涨停 {0} · 跌停 {1} · 炸板 {10}</span>"
            "<span class=\"card-meta\">东方财富涨停池/炸板池<br>首板占比 {2:.1f}%</span></div>"
            "<div class=\"card-body\">"
            "<div style=\"display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px\">"
            "<div class=\"breadth-cell red\" style=\"flex:1\"><div class=\"b-num\">{3}</div><div class=\"b-label\">今日涨停</div></div>"
            "<div class=\"breadth-cell green\" style=\"flex:1\"><div class=\"b-num\">{4}</div><div class=\"b-label\">今日跌停</div></div>"
            "<div class=\"breadth-cell up\" style=\"flex:1\"><div class=\"b-num small\">{5}板</div><div class=\"b-label\">最高连板 · {6}</div></div>"
            "<div class=\"breadth-cell gray\" style=\"flex:1\"><div class=\"b-num small\">{7}%</div><div class=\"b-label\">首板占比</div></div>"
            "<div class=\"breadth-cell\" style=\"flex:1;border:1px solid #bcd0f5;background:#f5f8ff\"><div class=\"b-num small\" style=\"color:#2E6FE0\">{10}</div><div class=\"b-label\">今日炸板</div></div>"
            "</div>"
            "<div style=\"font-size:11px;color:#8a8a8a;margin-bottom:10px;line-height:1.6\">连板分布：{8}</div>"
            "<div class=\"table-wrap\"><table>"
            "<thead><tr><th>涨停题材</th><th>涨停数</th><th>最高连板</th><th>领涨个股</th></tr></thead>"
            "<tbody>{9}</tbody></table></div>"
            "</div></div>").format(
                count, limit_down, first_pct,
                count, limit_down, max_board, esc(max_name), first_pct,
                esc(board_txt), ind_rows, zha_count)


def build_limit_trend_card():
    """近15交易日 涨停/跌停 双折线图独立卡片（位于市场指数卡片正下方）
    数据不足 2 天时返回空字符串，完全向后兼容。"""
    trend_svg = _build_limit_trend_svg(limit_history)
    if not trend_svg:
        return ""
    return ("<div class=\"card\" id=\"limit-trend\"><div class=\"card-head\">"
            "<span class=\"card-title\">涨跌停 15 日趋势</span>"
            "<span class=\"card-count\">近15个交易日</span>"
            "<span class=\"card-meta\">东方财富涨停/跌停/炸板池<br>红=涨停 · 绿=跌停 · 蓝=炸板</span></div>"
            "<div class=\"card-body\">{}</div></div>").format(trend_svg)


def build_strength_html():
    """主线强度评分 TOP6"""
    if not sector_strength:
        return ""
    top = sector_strength[:6]
    rows = []
    for i, s in enumerate(top, 1):
        score = s.get("score", 0)
        # 强度条颜色: >=75 红深, >=60 红, >=45 橙, else 灰
        if score >= 75: bar = "#E60012"; txt = "强"
        elif score >= 60: bar = "#f5485a"; txt = "较强"
        elif score >= 45: bar = "#ff9f43"; txt = "中"
        else: bar = "#bdbdbd"; txt = "弱"
        rows.append(
            "<div style=\"display:flex;align-items:center;gap:10px;margin-bottom:9px\">"
            "<div style=\"width:88px;font-size:12px;font-weight:600\">{}</div>"
            "<div style=\"flex:1;height:12px;background:#f1f1f1;border-radius:6px;overflow:hidden\">"
            "<div style=\"height:100%;width:{}%;background:{};border-radius:6px\"></div></div>"
            "<div style=\"width:58px;text-align:right;font-size:12.5px;font-weight:800;color:{}\">{}</div>"
            "<div style=\"width:26px;font-size:10.5px;color:#8a8a8a\">{}</div></div>".format(
                esc(s.get("name")), min(100, score), bar, bar, score, txt))
    return ("<div class=\"card\" id=\"strength\"><div class=\"card-head\">"
            "<span class=\"card-title\">主线强度评分</span>"
            "<span class=\"card-count\">TOP6 · 100分制</span>"
            "<span class=\"card-meta\">规则评分<br>涨跌幅+资金+涨停家数</span></div>"
            "<div class=\"card-body\">{}</div></div>").format("".join(rows))


def build_style_html():
    """市场风格分析"""
    if not market_style:
        return ""
    def _cell(key, label):
        it = market_style.get(key) or {}
        lbl = it.get("label", "—")
        score = it.get("score", 0)
        # 类型: 占优→红, 均衡→灰, 收缩→绿
        if "收缩" in lbl or "占优" in lbl:
            color = "#0a8a3a" if "收缩" in lbl else "#E60012"
        else:
            color = "#4a4a4a"
        return ("<div class=\"breadth-cell\" style=\"border:1px solid #ececec\">"
                "<div class=\"b-label\" style=\"color:#8a8a8a;margin-bottom:4px\">{}</div>"
                "<div class=\"b-num small\" style=\"color:{}\">{}</div>"
                "<div class=\"b-label\" style=\"margin-top:3px\">强度 {} / 100</div></div>").format(
                    label, color, esc(lbl), score)
    return ("<div class=\"card\"><div class=\"card-head\">"
            "<span class=\"card-title\">市场风格分析</span>"
            "<span class=\"card-count\">{}</span>"
            "<span class=\"card-meta\">涨跌家数 {} / {}<br>规则聚类判断</span></div>"
            "<div class=\"card-body\"><div class=\"breadth-grid\" style=\"grid-template-columns:repeat(2,1fr);gap:10px\">"
            "{}{}{}{}</div></div></div>").format(
                esc((market_style.get("risk") or {}).get("label", "")),
                (market_style.get("breadth") or {}).get("up", ""), (market_style.get("breadth") or {}).get("down", ""),
                _cell("cap", "大盘 / 小盘"), _cell("gv", "成长 / 价值"),
                _cell("grp", "科技 / 周期 / 消费"), _cell("risk", "风险偏好"))


def build_changes_html():
    """今日最大变化 TOP5"""
    if not top_changes:
        return ""
    rows = []
    for i, c in enumerate(top_changes, 1):
        strong = c.get("type") == "增强"
        color = "#E60012" if strong else "#0a8a3a"
        badge = "增强" if strong else "减弱"
        rows.append(
            "<tr><td>{}</td><td class=\"name\">{}</td><td><span style=\"color:{};font-weight:700\">{}</span></td>"
            "<td class=\"reason\" style=\"max-width:320px\">{}</td></tr>".format(
                i, esc(c.get("name")), color, badge, esc(c.get("desc"))))
    return ("<div class=\"card\"><div class=\"card-head\">"
            "<span class=\"card-title\">今日最大变化 TOP5</span>"
            "<span class=\"card-count\">资金 + 价格异动</span></div>"
            "<div class=\"table-wrap\"><table>"
            "<thead><tr><th>#</th><th>板块</th><th>方向</th><th>变化说明</th></tr></thead>"
            "<tbody>{}</tbody></table></div></div>").format("".join(rows))


def build_focus_html():
    """明日重点观察 TOP3"""
    if not focus_tomorrow:
        return ""
    items = []
    for i, f in enumerate(focus_tomorrow, 1):
        items.append(
            "<div class=\"chip\" style=\"font-size:12px;padding:5px 12px\">{}. {} <span style=\"color:#8a8a8a\">{}分</span></div>".format(
                i, esc(f.get("name")), f.get("score", 0)))
    return ("<div class=\"card\"><div class=\"card-head\">"
            "<span class=\"card-title\">明日重点观察</span>"
            "<span class=\"card-count\">强度TOP3</span>"
            "<span class=\"card-meta\">聚焦高景气主线<br>验证资金持续性</span></div>"
            "<div class=\"card-body\"><div class=\"chips\">{}</div></div></div>").format("".join(items))


industry_flow_html = build_industry_flow_html()
limit_updown_html = build_limit_updown_html()
limit_trend_html = build_limit_trend_card()
strength_html = build_strength_html()
style_html = build_style_html()
changes_html = build_changes_html()
focus_html = build_focus_html()
# 成交额格式化(万元→亿)
amount_yi = amount_wan / 10000 if amount_wan else 0

css = """
:root {
  --bv-red: #E60012; --bv-red-deep: #C00010; --bv-red-soft: #FDECEE;
  --bv-ink: #1a1a2e; --bv-gray-1: #4a4a4a; --bv-gray-2: #8a8a8a;
  --bv-line: #ececec; --bv-bg: #f7f7f7; --bv-white: #fff;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Source Han Sans SC",sans-serif; background:var(--bv-bg); color:var(--bv-ink); -webkit-font-smoothing:antialiased; }
.topbar { background:var(--bv-white); border-bottom:1px solid var(--bv-line); padding:12px 32px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:100; }
.brand { display:flex; align-items:center; gap:12px; }
.brand img { height:36px; width:auto; display:block; }
.brand-text { display:flex; flex-direction:column; line-height:1.15; }
.brand-zh { font-size:14px; color:var(--bv-red); font-weight:700; letter-spacing:2px; }
.brand-en { font-size:10px; color:var(--bv-gray-1); letter-spacing:1.2px; margin-top:2px; }
.nav { display:flex; gap:28px; }
.nav a { color:var(--bv-ink); text-decoration:none; font-size:13px; font-weight:500; padding:6px 0; border-bottom:2px solid transparent; }
.nav a:hover, .nav a.active { color:var(--bv-red); border-bottom-color:var(--bv-red); }
.container { max-width:1280px; margin:0 auto; padding:22px 24px 30px; }
.banner { background:linear-gradient(135deg, var(--bv-red) 0%, var(--bv-red-deep) 100%); border-radius:12px; padding:30px 36px; color:#fff; margin-bottom:18px; position:relative; overflow:hidden; }
.banner::after { content:""; position:absolute; right:-42px; bottom:-48px; width:220px; height:220px; background:rgba(255,255,255,.07); border-radius:50%; }
.banner::before { content:""; position:absolute; right:90px; bottom:-78px; width:150px; height:150px; background:rgba(255,255,255,.05); border-radius:50%; }
.banner .crumb { font-size:11px; opacity:.85; letter-spacing:2.4px; margin-bottom:8px; }
.banner h1 { font-size:28px; font-weight:800; letter-spacing:1px; line-height:1.3; position:relative; z-index:1; }
.banner h1 .accent { background:#fff; color:var(--bv-red); padding:2px 14px; border-radius:4px; margin-right:10px; font-size:21px; vertical-align:middle; }
.banner .meta { font-size:12px; opacity:.94; margin-top:13px; line-height:1.9; position:relative; z-index:1; }
.banner .meta b { background:rgba(255,255,255,.18); padding:1px 8px; border-radius:3px; margin:0 2px; font-weight:600; }
.stats { display:grid; grid-template-columns:repeat(8,1fr); gap:10px; margin-bottom:16px; }
.stat { background:var(--bv-white); border:1px solid var(--bv-line); border-radius:8px; padding:14px 14px 12px; }
.stat .num { font-size:21px; font-weight:800; color:var(--bv-red); line-height:1.15; letter-spacing:-.02em; }
.stat .num.small { font-size:17px; }
.stat.gray .num { color:var(--bv-gray-1); }
.stat.green .num { color:#0a8a3a; }
.stat .label { font-size:10.5px; color:var(--bv-gray-2); margin-top:5px; line-height:1.4; }
.note { background:var(--bv-red-soft); border-left:4px solid var(--bv-red); padding:11px 16px; border-radius:0 6px 6px 0; font-size:12.5px; color:#5a0a13; margin-bottom:16px; line-height:1.85; }
.note b { color:var(--bv-red-deep); }
.row2 { display:grid; grid-template-columns:1fr 1.08fr; gap:14px; margin-bottom:14px; }
.row3 { display:grid; grid-template-columns:1.25fr 1fr; gap:14px; margin-bottom:14px; }
.row2.market-row { grid-template-columns: 1.9fr 1fr; }
.row2.flow-row { grid-template-columns: 1fr 1fr; }
.card { background:var(--bv-white); border:1px solid var(--bv-line); border-radius:10px; overflow:hidden; }
.card + .card { margin:0; }
.card-head { display:flex; align-items:center; gap:12px; background:var(--bv-red-soft); padding:10px 16px; border-bottom:2px solid var(--bv-red); }
.card-title { font-size:14px; font-weight:800; color:var(--bv-red); }
.card-count { font-size:11px; background:var(--bv-red); color:#fff; padding:2px 10px; border-radius:10px; font-weight:700; white-space:nowrap; }
.card-meta { font-size:10.5px; color:var(--bv-gray-1); margin-left:auto; text-align:right; line-height:1.5; }
.card-body { padding:14px 16px; }
.chart-box { width:100%; }
.chips { display:flex; flex-wrap:wrap; gap:6px; margin-top:12px; }
.chip { font-size:10.5px; padding:3px 9px; border-radius:12px; color:var(--bv-red); font-weight:600; border:1px solid; white-space:nowrap; }
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:12px; }
thead th { background:var(--bv-red); color:#fff; padding:8px 10px; text-align:left; font-weight:700; border:none; white-space:nowrap; letter-spacing:.5px; font-size:11px; }
tbody td { padding:6.5px 10px; border-bottom:1px solid var(--bv-line); white-space:nowrap; }
tbody tr:hover { background:#fafafa; }
.up { color:var(--bv-red); font-weight:700; }
.down { color:#0a8a3a; font-weight:600; }
.code { font-family:Consolas,monospace; color:var(--bv-gray-1); font-size:11px; }
.name { font-weight:600; color:var(--bv-ink); }
.reason { font-size:11px; color:var(--bv-gray-2); max-width:250px; overflow:hidden; text-overflow:ellipsis; }
.footer { text-align:center; color:var(--bv-gray-2); font-size:11px; margin-top:22px; padding-top:16px; border-top:1px solid var(--bv-line); line-height:1.9; }
.footer .bv { color:var(--bv-red); font-weight:700; }
.export-bar { position:fixed; right:16px; bottom:16px; z-index:999; display:flex; gap:8px; background:rgba(255,255,255,.97); padding:8px 12px; border-radius:10px; box-shadow:0 4px 14px rgba(230,0,18,.18); border:1px solid #f5b8be; }
.export-bar .btn { border:none; cursor:pointer; font-size:12px; font-weight:700; padding:7px 12px; border-radius:6px; color:#fff; background:var(--bv-red); }
.export-bar .btn:hover { background:var(--bv-red-deep); }
.export-bar .btn-green { background:#0a8a3a; }
.export-bar .btn-green:hover { background:#07752f; }
.export-bar .btn:disabled { background:#b9b9b9; cursor:wait; }
/* 市场指数 / 宽度 / 资金 */
.index-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:10px; }
.index-cell { background:#fafafa; border:1px solid var(--bv-line); border-radius:8px; padding:13px 10px 11px; text-align:center; }
.index-name { font-size:11.5px; color:var(--bv-gray-1); font-weight:600; }
.index-close { font-size:17px; font-weight:800; color:var(--bv-ink); margin-top:5px; letter-spacing:-.02em; }
.index-chg { font-size:12.5px; font-weight:800; margin-top:3px; }
.breadth-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; }
.breadth-cell { background:#fafafa; border:1px solid var(--bv-line); border-radius:8px; padding:13px 12px 11px; text-align:center; }
.breadth-cell .b-num { font-size:19px; font-weight:800; letter-spacing:-.02em; }
.breadth-cell .b-num.small { font-size:15px; }
.breadth-cell .b-label { font-size:10.5px; color:var(--bv-gray-2); margin-top:4px; }
.breadth-cell.red .b-num { color:var(--bv-red); }
.breadth-cell.green .b-num { color:#0a8a3a; }
.breadth-cell.gray .b-num { color:var(--bv-gray-1); }
.breadth-cell.up .b-num { color:var(--bv-red); }
.breadth-cell.down .b-num { color:#0a8a3a; }
/* 龙虎榜筛选栏 */
.filter-bar { display:flex; align-items:center; gap:8px; padding:10px 16px; border-bottom:1px solid var(--bv-line); background:#fafafa; flex-wrap:wrap; }
.f-input { flex:1; min-width:150px; max-width:230px; padding:6px 11px; border:1px solid #e3e3e3; border-radius:6px; font-size:12px; outline:none; color:var(--bv-ink); background:#fff; }
.f-input:focus { border-color:var(--bv-red); box-shadow:0 0 0 2px rgba(230,0,18,.08); }
.f-select { padding:6px 9px; border:1px solid #e3e3e3; border-radius:6px; font-size:12px; background:#fff; color:var(--bv-ink); outline:none; cursor:pointer; max-width:300px; }
.f-select:focus { border-color:var(--bv-red); }
.f-count { margin-left:auto; font-size:12px; color:var(--bv-gray-1); font-weight:700; white-space:nowrap; }
@media print { .topbar, .export-bar { display:none !important; } .container { max-width:100%; padding:0; } }
@media(max-width:1180px){ .stats { grid-template-columns:repeat(4,1fr); } .index-grid { grid-template-columns:repeat(3,1fr); } .breadth-grid { grid-template-columns:repeat(2,1fr); } }
@media(max-width:900px){ .nav { display:none; } .row2, .row3 { grid-template-columns:1fr; } .stats { grid-template-columns:repeat(2,1fr); } .banner { padding:24px 20px; } .banner h1 { font-size:23px; } .banner h1 .accent { display:inline-block; margin-bottom:6px; } .index-grid { grid-template-columns:repeat(2,1fr); } }
@media(max-width:560px){ .stats { grid-template-columns:repeat(2,1fr); } .container { padding:14px 12px 24px; } .topbar { padding:10px 14px; } }
"""

html_doc = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>市场情绪日报 · BVIEW · {date}</title>
<style>{css}</style>
</head>
<body>
<header class="topbar">
  <div class="brand">
    <img src="{logo}" alt="商业瞰 BVIEW">
    <div class="brand-text">
      <span class="brand-zh">商业瞰</span>
      <span class="brand-en">BVIEW · BUSINESS INSIGHT</span>
    </div>
  </div>
  <nav class="nav">
    <a href="#" class="active">首页</a>
    <a href="#lhb">龙虎榜</a>
    <a href="#replay-flow">复盘增强</a>
    <a href="#limitup">涨跌停</a>
    <a href="#strength">主线强度</a>
    <a href="#topics">题材热榜</a>
    <a href="#industry">行业轮动</a>
    <a href="#etf-flow">ETF资金</a>
    <a href="#gem-flow">创业板资金</a>
  </nav>
</header>

<div class="container">
  <section class="banner">
    <div class="crumb">BVIEW · 市场情绪 · 龙虎榜 + 题材热点 + 行业轮动</div>
    <h1><span class="accent">市场情绪日报</span>{date}</h1>
    <div class="meta">
      数据日期 <b>{date}</b>（{weekday}） · 沪深成交额 <b>{amount_yi:.2f}亿</b> · 涨停 <b>{lu_count}只</b> / 跌停 <b>{ld_count}只</b> · 龙虎榜 <b>东方财富</b> · 强势股题材 <b>同花顺</b> · 行业板块 <b>东方财富行业</b><br>
      上榜记录 <b>{total_records}条</b> · 去重 <b>{unique_codes}只</b> · 净买入合计 <b>{total_net}</b> · 最热题材 <b>{hottest}</b> · 领涨行业 <b>{leading_ind} {leading_ind_chg}</b>
    </div>
  </section>

  <div class="stats">
    <div class="stat"><div class="num">{total_records}</div><div class="label">龙虎榜上榜记录</div></div>
    <div class="stat gray"><div class="num small">{unique_codes}</div><div class="label">去重个股</div></div>
    <div class="stat"><div class="num">{total_net}</div><div class="label">净买入合计</div></div>
    <div class="stat gray"><div class="num">{strong_count}</div><div class="label">同花顺强势股</div></div>
    <div class="stat gray"><div class="num small">{tag_count}</div><div class="label">题材标签总数</div></div>
    <div class="stat"><div class="num small">{hottest} ×{hottest_count}</div><div class="label">最热题材覆盖</div></div>
    <div class="stat"><div class="num small">{leading_ind}</div><div class="label">领涨行业 {leading_ind_chg}</div></div>
    <div class="stat green"><div class="num small">{ind_up}涨 · {ind_down}跌</div><div class="label">行业板块涨跌</div></div>
  </div>

  <div class="row2 market-row">
    <div class="card" id="indexes">
      <div class="card-head">
        <span class="card-title">市场指数</span>
        <span class="card-count">上证 / 创业板 / 科创50 / 恒生 / 日经</span>
        <span class="card-meta">东方财富行情<br>红涨绿跌 · 单位：点</span>
      </div>
      <div class="card-body">
        <div class="index-grid">{index_cards}</div>
      </div>
    </div>
    <div class="card" id="breadth">
      <div class="card-head">
        <span class="card-title">市场宽度 · 资金</span>
        <span class="card-count">沪深全市场</span>
        <span class="card-meta">东方财富统计<br>大盘主力资金口径</span>
      </div>
      <div class="card-body">
        <div class="breadth-grid">{breadth_cards}</div>
      </div>
    </div>
  </div>

  {limit_trend_html}

  <div class="note">
    <b>当日复盘要点</b>：东财龙虎榜全市场共 <b>{total_records}</b> 条上榜记录（去重 <b>{unique_codes}</b> 只），净买入合计 <b>{total_net}</b>。同花顺强势股题材归因共 <b>{strong_count}</b> 只 × <b>{tag_count}</b> 个标签，最热题材为 <b>{hottest}</b>（{hottest_count}只），其后为 <b>{topic2}</b>（{topic2c}只）、<b>{topic3}</b>（{topic3c}只）。行业板块 <b>{ind_up}涨{ind_down}跌</b>，领涨 <b>{leading_ind} {leading_ind_chg}</b>，领跌 <b>{lagging_ind} {lagging_ind_chg}</b>。
  </div>

  <div class="row2">
    <div class="card" id="topics">
      <div class="card-head">
        <span class="card-title">题材热度 TOP10</span>
        <span class="card-count">{strong_count}只强势股</span>
        <span class="card-meta">同花顺 reason 标签<br>按 + 拆分词频统计</span>
      </div>
      <div class="card-body">
        <div class="chart-box">{topic_svg}</div>
        <div class="chips">{topic_chips}</div>
      </div>
    </div>

    <div class="card" id="industry">
      <div class="card-head">
        <span class="card-title">行业板块涨跌榜</span>
        <span class="card-count">{ind_total}个行业</span>
        <span class="card-meta">东方财富行业板块<br>涨 {ind_up} · 跌 {ind_down}</span>
      </div>
      <div class="card-body">
        <div class="chart-box">{ind_svg}</div>
        <div style="height:14px"></div>
        <div class="chart-box">{ind_overview_svg}</div>
      </div>
    </div>
  </div>

  <div class="row2 flow-row" id="replay-flow">
    {industry_flow_html}
  </div>

  <div class="row2 flow-row">
    {limit_updown_html}
    {strength_html}
  </div>

  <div class="row2 flow-row">
    {style_html}
    {focus_html}
  </div>

  <div style="margin-bottom:14px">
    {changes_html}
  </div>

  <div class="row3">
    <div class="card" id="lhb">
      <div class="card-head">
        <span class="card-title">龙虎榜净买入 TOP10</span>
        <span class="card-count">按净买入降序</span>
        <span class="card-meta">东方财富龙虎榜<br>金额单位：万 / 亿</span>
      </div>
      <div class="card-body">
        <div class="chart-box">{lhb_svg}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <span class="card-title">强势股涨幅 TOP12</span>
        <span class="card-count">同花顺热点</span>
        <span class="card-meta">按当日涨幅降序<br>含题材归因</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>代码</th><th>名称</th><th>涨幅</th><th>题材归因</th></tr></thead>
          <tbody>{strong_rows}</tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="row2 flow-row">
    <div class="card" id="etf-flow">
      <div class="card-head">
        <span class="card-title">ETF 主力资金流 TOP</span>
        <span class="card-count">净流入20 · 净流出20</span>
        <span class="card-meta">东方财富场内基金<br>主力净流入 · 单位：亿元</span>
      </div>
      <div class="card-body">
        <div class="chart-box">{etf_svg}</div>
      </div>
    </div>
    <div class="card" id="gem-flow">
      <div class="card-head">
        <span class="card-title">创业板个股主力资金流</span>
        <span class="card-count">净流入20 · 净流出20</span>
        <span class="card-meta">东方财富创业板<br>主力净流入 · 单位：亿元</span>
      </div>
      <div class="card-body">
        <div class="chart-box">{gem_svg}</div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-head">
      <span class="card-title">龙虎榜 · 全部上榜明细</span>
      <span class="card-count">{total_records}条</span>
      <span class="card-meta">按净买入降序 · 东方财富龙虎榜 · 全市场口径<br>支持按代码 / 名称 / 方向 / 上榜原因筛选</span>
    </div>
    <div class="filter-bar">
      <input type="text" id="lhbSearch" class="f-input" placeholder="搜索代码 / 名称…">
      <select id="lhbNet" class="f-select">
        <option value="all">全部方向</option>
        <option value="pos">仅净买入</option>
        <option value="neg">仅净卖出</option>
      </select>
      <select id="lhbReason" class="f-select">
        <option value="all">全部上榜原因</option>
        {lhb_reason_options}
      </select>
      <span class="f-count" id="lhbCount"></span>
    </div>
    <div class="table-wrap">
      <table id="lhbTable">
        <thead><tr><th>#</th><th>代码</th><th>名称</th><th>收盘</th><th>涨跌幅</th><th>净买入</th><th>买入额</th><th>卖出额</th><th>上榜原因</th><th>换手率</th></tr></thead>
        <tbody>{lb_table}</tbody>
      </table>
    </div>
  </div>

  <div class="footer">
    <span class="bv">商业瞰 BVIEW</span> · 数据来源：东方财富龙虎榜 / 同花顺强势股热点 / 东方财富行业板块 · 交易日期 <b>{date}</b><br>
    数据仅供研究参考，不构成投资建议 · 生成时间 {gen_time}
  </div>
</div>

<div class="export-bar">
  <button class="btn btn-green" id="btnDl" onclick="downloadImage()">下载图片</button>
  <button class="btn" onclick="window.print()">打印 / 导出 PDF</button>
</div>
<script>
  function downloadImage() {{
    var btn = document.getElementById('btnDl');
    var target = document.querySelector('.container') || document.body;
    var html2canvasSrc = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
    function grab() {{
      var full = document.documentElement.scrollHeight;
      window.scrollTo(0, 0);
      setTimeout(function () {{
        html2canvas(target, {{
          scale: 1.5,
          useCORS: true,
          backgroundColor: null,
          logging: false,
          onclone: function (doc, el) {{
            var t = doc.querySelector('.topbar');
            if (t) t.style.position = 'relative';
            var e = doc.querySelector('.export-bar');
            if (e) e.style.display = 'none';
            var l = doc.querySelectorAll('.lazy');
            for (var i = 0; i < l.length; i++) l[i].src = l[i].getAttribute('data-src') || l[i].src;
          }}
        }}).then(function (canvas) {{
          var a = document.createElement('a');
          a.download = 'A股市场情绪日报_BVIEW_{STAMP}.png';
          a.href = canvas.toDataURL('image/png');
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          btn.disabled = false;
          btn.textContent = '下载图片';
          setTimeout(function () {{ window.scrollTo(0, 0); }}, 100);
        }}).catch(function (e) {{
          alert('截图失败: ' + e.message);
          btn.disabled = false;
          btn.textContent = '下载图片';
        }});
      }}, 60);
    }}
    if (typeof html2canvas === 'undefined') {{
      var s = document.createElement('script');
      s.src = html2canvasSrc;
      s.onload = grab;
      s.onerror = function () {{
        alert('加载截图组件失败，请检查网络后重试');
        btn.disabled = false;
        btn.textContent = '下载图片';
      }};
      document.head.appendChild(s);
    }} else {{
      grab();
    }}
  }}
(function () {{
  var total = {total_records};
  var rows = Array.prototype.slice.call(document.querySelectorAll('#lhbTable tbody tr'));
  var search = document.getElementById('lhbSearch');
  var netSel = document.getElementById('lhbNet');
  var rsSel = document.getElementById('lhbReason');
  var cnt = document.getElementById('lhbCount');
  function apply() {{
    var q = search.value.trim().toLowerCase();
    var net = netSel.value;
    var rs = rsSel.value;
    var show = 0;
    rows.forEach(function (tr) {{
      var ok = true;
      if (q) {{
        var t = (tr.getAttribute('data-code') + ' ' + tr.getAttribute('data-name')).toLowerCase();
        if (t.indexOf(q) < 0) ok = false;
      }}
      if (ok && net !== 'all') {{
        var v = parseFloat(tr.getAttribute('data-net'));
        if (net === 'pos' && v <= 0) ok = false;
        if (net === 'neg' && v >= 0) ok = false;
      }}
      if (ok && rs !== 'all' && tr.getAttribute('data-reason') !== rs) ok = false;
      tr.style.display = ok ? '' : 'none';
      if (ok) show++;
    }});
    cnt.textContent = '显示 ' + show + ' / ' + total + ' 条';
  }}
  search.addEventListener('input', apply);
  netSel.addEventListener('change', apply);
  rsSel.addEventListener('change', apply);
  apply();
}})();
</script>
</body>
</html>""".format(
    date=TRADE_DATE,
    weekday=WEEKDAY,
    css=css,
    logo=LOGO_URI,
    total_records=total_records,
    unique_codes=unique_codes,
    total_net=fmt_amount(total_net_wan),
    strong_count=len(strong_stocks),
    tag_count=tag_count,
    hottest=esc(hottest),
    hottest_count=hottest_count,
    leading_ind=esc(leading_ind),
    leading_ind_chg=fmt_pct(leading_ind_chg),
    lagging_ind=esc(lagging_ind),
    lagging_ind_chg=fmt_pct(lagging_ind_chg),
    ind_up=ind_up,
    ind_down=ind_down,
    ind_total=len(industries),
    topic2=esc(top_topics[1][0]) if len(top_topics) > 1 else "—",
    topic2c=top_topics[1][1] if len(top_topics) > 1 else 0,
    topic3=esc(top_topics[2][0]) if len(top_topics) > 2 else "—",
    topic3c=top_topics[2][1] if len(top_topics) > 2 else 0,
    topic_svg=topic_svg,
    topic_chips=topic_chips,
    ind_svg=ind_svg,
    ind_overview_svg=ind_overview_svg,
    lhb_svg=lhb_svg,
    index_cards=index_cards,
    breadth_cards=breadth_cards,
    limit_trend_html=limit_trend_html,
    etf_svg=etf_svg,
    gem_svg=gem_svg,
    lhb_reason_options=lhb_reason_options,
    strong_rows=strong_rows,
    lb_table=lb_table,
    industry_flow_html=industry_flow_html,
    limit_updown_html=limit_updown_html,
    strength_html=strength_html,
    style_html=style_html,
    changes_html=changes_html,
    focus_html=focus_html,
    amount_yi=amount_yi,
    lu_count=limit_up.get("count", "-") or "-",
    ld_count=limit_down if limit_down is not None else "-",
    gen_time=__import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M"),
    STAMP=STAMP)

with open(OUTPUT, "w", encoding="utf-8") as f:
    f.write(html_doc)

size = os.path.getsize(OUTPUT)
print("生成完成: {}".format(OUTPUT))
print("文件大小: {:.1f} KB".format(size / 1024))
print("龙虎榜 {} 条 / 去重 {} 只 | 题材标签 {} 个 | 行业 {} 个".format(total_records, unique_codes, tag_count, len(industries)))
print("最热题材: {} ({}只) | 领涨: {} {} | 领跌: {} {}".format(hottest, hottest_count, leading_ind, fmt_pct(leading_ind_chg), lagging_ind, fmt_pct(lagging_ind_chg)))

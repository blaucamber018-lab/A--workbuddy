# -*- coding: utf-8 -*-
"""A股市场情绪日报 - 近15个交易日涨跌停历史抓取 (fetch_limit_history.py)
在 market_data_{date}.json 基础上，新增 replay.limit_history 字段：
  limit_history = [{date: "YYYY-MM-DD", up: 涨停数, down: 跌停数}, ...]  （按日期升序，最多15条）

数据获取顺序（缓存优先，减少第三方接口调用）：
  1. 本地 market_data_{stamp}.json 中已有 limit_up.count / limit_down → 直接复用
  2. 否则调东财涨停池 getTopicZTPool / 跌停池 getTopicDTPool 接口回溯拉取
交易日判定：周六/周日直接跳过；接口返回空且本地无缓存 → 视为非交易日/无数据，跳过。
用法: python fetch_limit_history.py [YYYY-MM-DD]   （默认当天，需先有 market_data JSON）
也可被 fetch_replay.py import 调用: from fetch_limit_history import build_limit_history
"""
import datetime
import json
import os
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
# 输出目录：REPORT_OUT_DIR（skill 分发场景）→ 否则脚本所在目录（自动化场景）
OUT_DIR = os.environ.get("REPORT_OUT_DIR") or HERE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
HDRS = {"User-Agent": UA, "Referer": "https://data.eastmoney.com/"}

# 回溯窗口：最多往前查 45 个自然日（保证凑满 15 个交易日）
MAX_BACK_DAYS = 45
HISTORY_N = 15  # 目标交易日数量


def get(url):
    req = urllib.request.Request(url, headers=HDRS)
    return json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))


def _retry(fn, tries=3, wait=2):
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            print("  重试 {}: {}".format(i + 1, repr(e)[:120]))
            time.sleep(wait)
    return None


def _fetch_pool(date_stamp, pool_name):
    """抓取某日涨停池(getTopicZTPool)/跌停池(getTopicDTPool)/炸板池(getTopicZBPool)记录数"""
    path = {"zt": "getTopicZTPool", "dt": "getTopicDTPool", "zha": "getTopicZBPool"}.get(pool_name, "getTopicZTPool")
    pagesize = {"zt": "400", "dt": "200", "zha": "400"}.get(pool_name, "400")
    sort = {"zt": "fbt:asc", "dt": "fund:asc", "zha": "fbt:asc"}.get(pool_name, "fbt:asc")
    url = "https://push2ex.eastmoney.com/{}?".format(path) + urllib.parse.urlencode({
        "ut": "7eea3edcaed734bea9cbfc24409ed989", "dpt": "wz.ztzt",
        "Pageindex": "0", "pagesize": pagesize, "sort": sort,
        "date": date_stamp, "_": str(int(time.time()))})

    def _f():
        d = get(url)
        return (d.get("data") or {}).get("pool") or []
    pool = _retry(_f)
    return len(pool) if pool is not None else None


def _from_local_cache(date_stamp):
    """从本地 market_data_{stamp}.json 读取涨停/跌停/炸板数；无缓存或无效返回 None"""
    p = os.path.join(OUT_DIR, "market_data_{}.json".format(date_stamp))
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        rp = d.get("replay") or {}
        lu = rp.get("limit_up") or {}
        up = lu.get("count")
        down = rp.get("limit_down")
        zha = (rp.get("zhaban") or {}).get("count")
        if up is None or down is None:
            return None
        return (int(up), int(down), int(zha) if zha is not None else 0)
    except Exception:
        return None


def _fetch_one_day(ds, date_stamp):
    """抓取单日涨跌停+炸板：优先本地缓存，其次接口。返回 (up, down, zha) 或 None（非交易日/无数据）"""
    cached = _from_local_cache(date_stamp)
    if cached is not None:
        return cached
    up = _fetch_pool(date_stamp, "zt")
    down = _fetch_pool(date_stamp, "dt")
    zha = _fetch_pool(date_stamp, "zha")
    if up is None or down is None:
        return None
    if up == 0 and down == 0:
        return None  # 非交易日或接口无数据
    return (up, down, zha if zha is not None else 0)


def build_limit_history(trade_date):
    """从 trade_date 往前回溯最近 HISTORY_N 个交易日涨跌停数据（含 trade_date 当天）。
    返回按日期升序的 [{date, up, down}, ...]，最多 HISTORY_N 条。"""
    cur = datetime.date.fromisoformat(trade_date)
    results = []
    seen = set()
    for _ in range(MAX_BACK_DAYS):
        if len(results) >= HISTORY_N:
            break
        if cur.weekday() >= 5:  # 周六/周日跳过
            cur -= datetime.timedelta(days=1)
            continue
        ds = cur.isoformat()
        date_stamp = ds.replace("-", "")
        got = _fetch_one_day(ds, date_stamp)
        if got is not None and date_stamp not in seen:
            seen.add(date_stamp)
            results.append({"date": ds, "up": got[0], "down": got[1], "zha": got[2]})
            print("  {}  涨停 {} · 跌停 {} · 炸板 {}".format(ds, got[0], got[1], got[2]))
        cur -= datetime.timedelta(days=1)
    results.sort(key=lambda x: x["date"])
    return results


def main():
    if len(sys.argv) > 1:
        trade_date = sys.argv[1]
    else:
        trade_date = datetime.date.today().isoformat()
    stamp = trade_date.replace("-", "")
    json_path = os.path.join(OUT_DIR, "market_data_{}.json".format(stamp))
    if not os.path.exists(json_path):
        raise SystemExit("JSON 不存在: {}（请先运行 fetch_data_0807 / fetch_flow_top20）".format(json_path))

    print("抓取近 {} 个交易日涨跌停历史（自 {} 起回溯）...".format(HISTORY_N, trade_date))
    history = build_limit_history(trade_date)
    with open(json_path, "r", encoding="utf-8") as f:
        d = json.load(f)
    rp = d.setdefault("replay", {})
    rp["limit_history"] = history
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    print("\n✅ limit_history 已写入 market_data_{}.json（{} 条）".format(stamp, len(history)))
    if history:
        ups = [x["up"] for x in history]
        downs = [x["down"] for x in history]
        zhas = [x["zha"] for x in history]
        print("  涨停: 均值 {:.0f} · 最高 {} / 最低 {}".format(
            sum(ups) / len(ups), max(ups), min(ups)))
        print("  跌停: 均值 {:.0f} · 最高 {} / 最低 {}".format(
            sum(downs) / len(downs), max(downs), min(downs)))
        print("  炸板: 均值 {:.0f} · 最高 {} / 最低 {}".format(
            sum(zhas) / len(zhas), max(zhas), min(zhas)))


if __name__ == "__main__":
    main()

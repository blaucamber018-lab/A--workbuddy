#!/usr/bin/env python3
"""A股市场情绪日报 - 数据抓取脚本（参数化，支持任意交易日）
数据源: 东财龙虎榜 + 同花顺热点 + 东财行业板块
用法: python fetch_data_0807.py [YYYY-MM-DD]   （省略则默认当天）
"""
import json
import sys
import os
import datetime
import time
import random
import requests
from collections import Counter

# ── 交易日参数化：默认当天 ──
if len(sys.argv) > 1:
    TRADE_DATE = sys.argv[1]
else:
    TRADE_DATE = datetime.date.today().isoformat()
HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.environ.get("REPORT_OUT_DIR") or os.getcwd()
STAMP = TRADE_DATE.replace("-", "")
OUT_PATH = os.path.join(OUT_DIR, "market_data_{}.json".format(STAMP))

# ── 缓存优先：目标 JSON 已存在则复用，避免重复抓取触发第三方限流(429) ──
if os.path.exists(OUT_PATH):
    print("✔ 缓存已存在，复用: {}".format(OUT_PATH))
    print("  （如需强制重抓，请删除该 JSON 文件后重跑）")
    sys.exit(0)

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36"
DATACENTER_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get"

# ── 东财防封：全局节流 + 会话复用 ──
EM_SESSION = requests.Session()
EM_SESSION.headers.update({"User-Agent": UA})
EM_MIN_INTERVAL = 1.2
_em_last_call = [0.0]

def em_get(url, params=None, headers=None, timeout=20, **kwargs):
    wait = EM_MIN_INTERVAL - (time.time() - _em_last_call[0])
    if wait > 0:
        time.sleep(wait + random.uniform(0.1, 0.5))
    try:
        return EM_SESSION.get(url, params=params, headers=headers, timeout=timeout, **kwargs)
    finally:
        _em_last_call[0] = time.time()

def eastmoney_datacenter(report_name, columns="ALL", filter_str="", page_size=50,
                          sort_columns="", sort_types="-1"):
    params = {
        "reportName": report_name, "columns": columns,
        "filter": filter_str, "pageNumber": "1", "pageSize": str(page_size),
        "sortColumns": sort_columns, "sortTypes": sort_types,
        "source": "WEB", "client": "WEB",
    }
    r = em_get(DATACENTER_URL, params=params, timeout=20)
    d = r.json()
    if d.get("result") and d["result"].get("data"):
        return d["result"]["data"]
    return []


# ═══════════════════════════════════════════
# 1. 全市场龙虎榜
# ═══════════════════════════════════════════
print(f"[1/3] 抓取全市场龙虎榜 {TRADE_DATE}...")
dragon_data = eastmoney_datacenter(
    "RPT_DAILYBILLBOARD_DETAILSNEW",
    filter_str=f"(TRADE_DATE>='{TRADE_DATE}')(TRADE_DATE<='{TRADE_DATE}')",
    page_size=500,
    sort_columns="BILLBOARD_NET_AMT", sort_types="-1",
)
print(f"  API 返回 {len(dragon_data)} 条")

dragon_stocks = []
for row in dragon_data:
    net_buy = (row.get("BILLBOARD_NET_AMT") or 0) / 10000
    dragon_stocks.append({
        "code": row.get("SECURITY_CODE", ""),
        "name": row.get("SECURITY_NAME_ABBR", ""),
        "reason": row.get("EXPLANATION", ""),
        "close": row.get("CLOSE_PRICE") or 0,
        "change_pct": round(float(row.get("CHANGE_RATE") or 0), 2),
        "net_buy_wan": round(net_buy, 1),
        "buy_wan": round((row.get("BILLBOARD_BUY_AMT") or 0) / 10000, 1),
        "sell_wan": round((row.get("BILLBOARD_SELL_AMT") or 0) / 10000, 1),
        "turnover_pct": round(float(row.get("TURNOVERRATE") or 0), 2),
        "amplitude_pct": round(float(row.get("AMPLITUDE_RATE") or 0), 2),
    })

total_stocks = len(dragon_stocks)
total_net_buy = sum(s["net_buy_wan"] for s in dragon_stocks)
print(f"  上榜 {total_stocks} 条，净买入合计 {total_net_buy:.0f}万元")


# ═══════════════════════════════════════════
# 2. 同花顺热点 — 强势股题材归因
# ═══════════════════════════════════════════
print(f"[2/3] 抓取同花顺热点 {TRADE_DATE}...")
ths_headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/117.0.0.0 Safari/537.36",
    "Referer": "http://www.10jqka.com.cn/",
}

hot_stocks = []

def enrich_hot_with_quotes(stocks):
    """同花顺 getharden 有时只返回代码/题材，用东财行情补真实价格。"""
    if not stocks:
        return stocks
    secids = ",".join(("1." if s["code"][0] in "569" else "0.") + s["code"] for s in stocks)
    try:
        r = requests.get(
            "https://push2delay.eastmoney.com/api/qt/ulist.np/get",
            params={
                "fltt": "2", "invt": "2",
                "fields": "f2,f3,f6,f8,f12,f14",
                "secids": secids,
                "ut": "bd1d9ddb04089700cf9c27f6f7426281",
            },
            headers=ths_headers, timeout=20,
        )
        rows = r.json().get("data", {}).get("diff") or []
        quote = {x.get("f12"): x for x in rows}
        for s in stocks:
            q = quote.get(s["code"], {})
            if not q:
                continue
            s["close"] = round(float(q.get("f2") or 0), 2)
            s["change_pct"] = round(float(q.get("f3") or 0), 2)
            s["turnover_pct"] = round(float(q.get("f8") or 0), 2)
            s["amount"] = round(float(q.get("f6") or 0) / 10000, 1)
        print(f"  东财行情补齐 {len(quote)} 只价格字段")
    except Exception as e:
        print(f"  东财行情补齐失败: {e}")
    return stocks

# 接口A: zx.10jqka.com.cn getharden（skill 推荐）
try:
    url_a = (f"http://zx.10jqka.com.cn/event/api/getharden/"
             f"date/{TRADE_DATE}/orderby/date/orderway/desc/charset/GBK/")
    r = requests.get(url_a, headers=ths_headers, timeout=15)
    d = r.json()
    if d.get("errocode", 0) == 0 and d.get("data"):
        for row in d["data"]:
            hot_stocks.append({
                "code": row.get("code", ""), "name": row.get("name", ""),
                "reason": row.get("reason", ""),
                "close": float(row.get("close", 0) or 0),
                "change_pct": float(row.get("zhangfu", 0) or 0),
                "turnover_pct": float(row.get("huanshou", 0) or 0),
                "amount": float(row.get("chengjiaoe", 0) or 0),
                "dde_net": float(row.get("ddejingliang", 0) or 0),
            })
        print(f"  接口A(zx getharden) 成功: {len(hot_stocks)} 只")
    else:
        print(f"  接口A 返回空/错误: {d.get('errormsg','')}")
except Exception as e:
    print(f"  接口A 失败: {e}")

# 接口B: eq.10jqka.com.cn strong_stock（备用）
if not hot_stocks:
    try:
        url_b = f"https://eq.10jqka.com.cn/open/api/board/hot/v1/strong_stock/list?date_type={TRADE_DATE.replace('-','')}"
        r = requests.get(url_b, headers=ths_headers, timeout=15)
        d = r.json()
        data = d.get("data", {})
        items = data.get("stock_list") or data.get("list") or []
        if items:
            for row in items:
                hot_stocks.append({
                    "code": row.get("code", ""), "name": row.get("name", ""),
                    "reason": row.get("reason", ""),
                    "close": float(row.get("close", 0) or 0),
                    "change_pct": float(row.get("zhangfu") or row.get("change_pct") or 0),
                    "turnover_pct": float(row.get("huanshou", 0) or 0),
                    "amount": float(row.get("chengjiaoe", 0) or 0),
                    "dde_net": float(row.get("ddejingliang", 0) or 0),
                })
            print(f"  接口B(eq strong_stock) 成功: {len(hot_stocks)} 只")
        else:
            print(f"  接口B 返回空: {str(d)[:200]}")
    except Exception as e:
        print(f"  接口B 失败: {e}")

# 补行情字段后，再统计题材词频
if hot_stocks:
    hot_stocks = enrich_hot_with_quotes(hot_stocks)

# 题材词频统计
all_tags = []
for s in hot_stocks:
    reason = s.get("reason", "")
    if reason:
        tags = [t.strip() for t in str(reason).split("+") if t.strip()]
        all_tags.extend(tags)
tag_counter = Counter(all_tags)
top_themes = tag_counter.most_common(20)
print(f"  题材种类 {len(tag_counter)} 个，TOP5: {[t[0] for t in top_themes[:5]]}")


# ═══════════════════════════════════════════
# 3. 东财行业板块排名
# ═══════════════════════════════════════════
print(f"[3/3] 抓取东财行业板块排名...")
def _safe_float(val, default="N/A"):
    if val is None or val == "" or val == "-":
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default

industry_rows = []
try:
    ind_hosts = ["https://push2.eastmoney.com", "https://push2delay.eastmoney.com"]
    ind_params = {
        "pn": "1", "pz": "100", "po": "1", "np": "1",
        "fltt": "2", "invt": "2",
        "fs": "m:90+t:2",
        "fields": "f2,f3,f4,f12,f13,f14,f104,f105,f128,f136,f140,f141,f207,f62,f66,f72,f78,f84,f184",
    }
    ind_headers = {"User-Agent": UA, "Referer": "https://data.eastmoney.com/"}
    collected = {}
    for host in ind_hosts:
        try:
            for pn in range(1, 7):
                ind_params["pn"] = str(pn)
                r = em_get(host + "/api/qt/clist/get", params=ind_params, headers=ind_headers, timeout=20)
                d = r.json()
                items = (d.get("data") or {}).get("diff") or []
                if not items:
                    break
                for item in items:
                    collected[item.get("f12")] = item
            if collected:
                break
        except Exception as e:
            print(f"  {host} 失败: {e}")
    items = list(collected.values())
    print(f"  push2 返回 {len(items)} 个行业")
    items.sort(key=lambda x: float(str(x.get("f3", 0) or 0)), reverse=True)
    for i, item in enumerate(items):
        industry_rows.append({
            "rank": i + 1,
            "name": item.get("f14", ""),
            "change_pct": item.get("f3", 0),
            "code": item.get("f12", ""),
            "up_count": item.get("f104", 0),
            "down_count": item.get("f105", 0),
            "leader": item.get("f140", ""),
            "leader_change": item.get("f136", 0),
            "main_net": str(_safe_float(item.get("f62"))),
            "main_ratio": str(_safe_float(item.get("f184"))),
        })
except Exception as e:
    print(f"  行业板块请求失败: {e}")

def _chg(r):
    try:
        return float(str(r.get("change_pct", 0) or 0))
    except (ValueError, TypeError):
        return 0.0

industry_rows.sort(key=_chg, reverse=True)
for i, row in enumerate(industry_rows):
    row["rank"] = i + 1

total_industries = len(industry_rows)
up_industries = sum(1 for r in industry_rows if _chg(r) > 0)
down_industries = sum(1 for r in industry_rows if _chg(r) < 0)
flat_industries = total_industries - up_industries - down_industries
leading = industry_rows[:10]
lagging = industry_rows[-10:][::-1]
print(f"  行业板块 {total_industries} 个，涨{up_industries} 跌{down_industries} 平{flat_industries}")


# ═══════════════════════════════════════════
# 4. 汇总保存为 JSON
# ═══════════════════════════════════════════
result = {
    "trade_date": TRADE_DATE,
    "dragon_tiger": {
        "total": total_stocks,
        "total_net_buy_wan": round(total_net_buy, 1),
        "stocks": dragon_stocks,
    },
    "hot_themes": {
        "total_stocks": len(hot_stocks),
        "total_tags": len(tag_counter),
        "top_themes": [{"name": t[0], "count": t[1]} for t in top_themes],
        "stocks": hot_stocks,
    },
    "industry": {
        "total": total_industries,
        "up": up_industries,
        "down": down_industries,
        "leading": leading,
        "lagging": lagging,
        "all": industry_rows,
    },
}

output_path = OUT_PATH

# ── 写盘保护：保留已有字段（market/fund_flow/replay 等），只更新本脚本负责的部分 ──
# 历史教训：整体覆盖写盘会把 fetch_market()/fetch_flow() 等其它脚本已写入的字段
# 全部冲掉；一旦东财域名断连导致后续脚本抓到空数据，JSON 里就会永久缺失
# market 等字段，最终渲染出「市场指数卡片空白」。因此这里改为加载旧 JSON 合并。
existing = {}
if os.path.exists(output_path):
    try:
        with open(output_path, "r", encoding="utf-8") as f:
            existing = json.load(f)
        print(f"  载入已有 JSON 以保留字段: {sorted(existing.keys())}")
    except Exception as e:
        print(f"  ⚠️ 载入旧 JSON 失败({e})，将从零写入")

existing["trade_date"] = result["trade_date"]
existing["dragon_tiger"] = result["dragon_tiger"]
existing["hot_themes"] = result["hot_themes"]
existing["industry"] = result["industry"]

with open(output_path, "w", encoding="utf-8") as f:
    json.dump(existing, f, ensure_ascii=False, indent=2)

print(f"  写盘后字段: {sorted(existing.keys())}")

print(f"\n✅ 数据已保存至 {output_path}")
print(f"   龙虎榜: {total_stocks}条 | 热点个股: {len(hot_stocks)}只 | 行业板块: {total_industries}个")

# -*- coding: utf-8 -*-
"""IPv4 优先连接补丁（东财反爬修复）

背景：2026-09-21 起，东财 push2*/push2ex 主机在 IPv6 端点直接断开连接
（curl 解析到 IPv6 2409:8c1e:... 时 server closed abruptly，IPv4 正常 HTTP 200）。
Python urllib / requests 的 getaddrinfo 默认返回 IPv6 优先时，所有东财接口
会 RemoteDisconnected / Connection aborted 失败。

本模块在 import 时即把 getaddrinfo 替换为只返回 IPv4 结果（AF_INET），
从而让 urllib / requests 全部走 IPv4。各抓取脚本须在发起任何网络请求之前
import 本模块。

用法:  import ipv4_first
"""
import socket

_orig_getaddrinfo = socket.getaddrinfo


def _ipv4_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    # 强制 family=AF_INET，过滤 IPv6（AF_INET6）
    return _orig_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)


socket.getaddrinfo = _ipv4_getaddrinfo
